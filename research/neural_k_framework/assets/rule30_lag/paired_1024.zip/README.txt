Rule30, E11, n=1024.

复算 / Recalculate (Python standard library):
  python research/rule30_e11_1024_norm_20261108/analyze.py
重画图 / Plot (Matplotlib):
  python research/rule30_e11_1024_norm_20261108/analyze.py --plot
复训 / Retrain (original local protocol: PyTorch, NumPy, Matplotlib, cuda:1):
  python research/rule30_e11_1024_norm_20261108/train.py --archive e11_input.zip --out new_run
  python research/rule30_e11_1024_norm_20261108/analyze.py --run new_run
三组共享数据、种子及每步抽样；不含大权重。/ Conditions share data, initializations and batches. No large weights.
