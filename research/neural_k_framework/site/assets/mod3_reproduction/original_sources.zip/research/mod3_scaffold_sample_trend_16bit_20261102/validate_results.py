"""独立复算16-bit的数据隔离、固定窗口和配对汇总，不启动GPU训练。"""
import ctypes
import argparse
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parents[1] / ".venv-gpu/Lib/site-packages"))
import numpy as np


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--smoke",action="store_true")
    args=parser.parse_args()
    out=HERE/("smoke" if args.smoke else "results")
    manifest=read(out/"MANIFEST.json")
    cfg=manifest["config"]
    for name,expected in manifest["frozen_sources"].items():
        assert sha(out/"source"/name)==expected
    verification=read(out/"VERIFICATION.json")
    assert verification["graph_eager_max_weight_error"]<2e-5
    assert verification["restored_step_max_weight_error"]<1e-7
    space=1<<cfg["bits"]
    split=space//2
    permutations={ds:np.random.default_rng(ds).permutation(space).astype(np.uint64) for ds in cfg["data_seeds"]}
    jobs,lookup=[],{}
    max_forward=0.
    for path in out.glob("data*_n*/result.json"):
        job=read(path)
        assert job["status"]=="complete" and job["step"]==cfg["max_steps"]
        assert job["n"] in cfg["counts"] and job["data_seed"] in cfg["data_seeds"]
        jobs.append(job)
        ids=permutations[job["data_seed"]]
        assert hashlib.sha256(ids.tobytes()).hexdigest()==job["data_ids_sha256"]
        with np.load(path.parent/"data_ids.npz",allow_pickle=False) as data:
            train,test=data["train"],data["test"]
            np.testing.assert_array_equal(train,ids[:job["n"]])
            np.testing.assert_array_equal(test,ids[split:])
            assert len(test)==split and np.intersect1d(train,test).size==0
        with np.load(path.parent/"forward_audit.npz",allow_pickle=False) as data:
            assert data["gpu_logits"].shape[-1]==2*cfg["bits"]
            error=float(np.max(np.abs(data["gpu_logits"]-data["numpy_logits"])))
        assert error<.002 and abs(error-job["numpy_final_forward_max_error"])<1e-12
        max_forward=max(max_forward,error)
        for row in job["rows"]:
            key=tuple(row[k] for k in ["n","data_seed","model_seed","arm","step"])
            assert key not in lookup
            lookup[key]=row
    assert len(jobs)==len(cfg["counts"])*len(cfg["data_seeds"])
    assert len({j["initial_weights_sha256"] for j in jobs})==1
    analysis=read(out/"ANALYSIS.json")
    expected_trials=len(cfg["data_seeds"])*len(cfg["model_seeds"])
    expected_rows=len(cfg["counts"])*2*len(cfg["stages"])
    assert len(analysis["summary"])==expected_rows
    windows={}
    for n in cfg["counts"]:
        for ds in cfg["data_seeds"]:
            for ms in cfg["model_seeds"]:
                left,right=[lookup[n,ds,ms,arm,0] for arm in ["direct","scaffold"]]
                assert left["train_endpoint_bce"]==right["train_endpoint_bce"]
                assert left["test_endpoint_exact"]==right["test_endpoint_exact"]
                for arm in ["direct","scaffold"]:
                    for stage in cfg["stages"]:
                        values=[lookup[n,ds,ms,arm,stage-i*cfg["eval_every"]]["test_endpoint_exact"] for i in range(cfg["summary_window_points"])]
                        windows[n,ds,ms,arm,stage]=(float(np.mean(values)),min(values))
    for row in analysis["summary"]:
        values=[]
        successes=fitted=0
        for ds in cfg["data_seeds"]:
            for ms in cfg["model_seeds"]:
                mean,minimum=windows[row["n"],ds,ms,row["arm"],row["stage"]]
                values.append(mean)
                successes+=minimum>=cfg["success_accuracy"]
                fitted+=lookup[row["n"],ds,ms,row["arm"],row["stage"]]["train_endpoint_bce"]<=cfg["fit_bce"]
        assert row["trials"]==expected_trials and row["complete_panel"]
        assert abs(float(np.mean(values))-row["test_mean"])<1e-12
        assert successes==row["stable_success_count"] and fitted==row["endpoint_fit_count"]
    assert len(analysis["pairs"])==len(cfg["counts"])*expected_trials*len(cfg["stages"])
    for row in analysis["pairs"]:
        n,ds,ms,stage=[row[k] for k in ["n","data_seed","model_seed","stage"]]
        change=100*(windows[n,ds,ms,"scaffold",stage][0]-windows[n,ds,ms,"direct",stage][0])
        assert abs(change-row["test_difference_pp"])<1e-10
    details=[]
    for n in cfg["counts"]:
        for ds in cfg["data_seeds"]:
            direct=float(np.mean([windows[n,ds,ms,"direct",cfg["max_steps"]][0] for ms in cfg["model_seeds"]]))*100
            scaffold=float(np.mean([windows[n,ds,ms,"scaffold",cfg["max_steps"]][0] for ms in cfg["model_seeds"]]))*100
            details.append({"n":n,"data_seed":ds,"direct_percent":direct,"scaffold_percent":scaffold,"difference_pp":scaffold-direct})
    final=[r for key,r in lookup.items() if key[-1]==cfg["max_steps"]]
    audit={"completed_groups":len(jobs),"trained_models":len(final),"nested_data_and_fixed_test":True,
           "paired_initialization":True,"summary_and_pairs_recomputed":True,"max_numpy_forward_error":max_forward,
           "train_exact_100_count":sum(r["train_endpoint_exact"]==1. for r in final),
           "train_bce_below_0_001_count":sum(r["train_endpoint_bce"]<=cfg["fit_bce"] for r in final),
           "group_execution_seconds":sum(j["seconds"] for j in jobs),"by_dataset":details}
    (out/"AUDIT.json").write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(audit,ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
