"""复用已核验训练核心，测16-bit Mod3的粗粒度数据需求趋势。"""
import ctypes
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / "mod3_scaffold_sample_trend_20261102"
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")
sys.path[:0] = [str(BASE), str(HERE.parents[1] / ".venv-gpu/Lib/site-packages")]
print("加载16-bit Mod3配对实验；14-bit结果保持不变", flush=True)

import argparse
import json
import shutil
import time
import torch
import experiment as core
import analyze


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--hours", type=float, default=2.)
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("需要GPU1，不回退CPU")
    device = torch.device("cuda:1")
    torch.cuda.set_device(device)
    torch.set_num_threads(4)
    torch.set_deterministic_debug_mode("error")
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    cfg = {"bits":16,"model_bits":30,"width":1024,"layers":3,
        "counts":[1024,2048,4096,8192,32768],"data_seeds":[202611020,202611021],"model_seeds":[0,1,2],
        "batch_seed":314159,"batch_size":512,"learning_rate":.001,"warmup_steps":10,
        "aux_lambda":1.,"max_steps":16000,"checkpoints":[8000,16000],"stages":[4000,8000,16000],
        "summary_window_points":3,"success_accuracy":.99,"fit_bce":.001,
        "eval_every":1000,"eval_chunk":512,"dtype":"float32","weight_decay":0.,"dropout":0.,
        "objective":"L_endpoint + lambda * mean_BCE(auxiliary_prefixes); lambda=0 or 1",
        "batch_sampling":"固定512，所有n均有放回抽样；同组配对模型共享batch",
        "train_split":"全空间一半作为嵌套训练池；另一半固定测试；辅助标签不进入测试输入",
        "source_sha256":core.sha(core.__file__),"legacy_sha256":core.sha(core.legacy.__file__),
        "model_source_sha256":core.sha(core.legacy.old.__file__),"driver_sha256":core.sha(__file__)}
    if args.smoke:
        cfg.update(width=32,counts=[256],data_seeds=[202611020],model_seeds=[0,1],batch_size=32,
                   max_steps=20,checkpoints=[10,20],stages=[10,20],summary_window_points=1,eval_every=10)
    previous = BASE / "results/MANIFEST.json"
    if previous.exists() and not args.smoke:
        old = json.loads(previous.read_text(encoding="utf-8"))["config"]
        changed = {key for key in old if old[key] != cfg.get(key)}
        if changed != {"bits","counts"}:
            raise RuntimeError(f"与14-bit协议出现额外差异：{changed}")
        if core.sha(BASE / "results/source/analyze.py") != core.sha(analyze.__file__):
            raise RuntimeError("14-bit分析核心已经变化，不混用")
    out = HERE / ("smoke" if args.smoke else "results")
    out.mkdir(exist_ok=True)
    sources = [Path(__file__),HERE/"validate_results.py",Path(core.__file__),Path(analyze.__file__),
               Path(core.legacy.__file__),Path(core.legacy.old.__file__)]
    manifest = {"config":cfg,"gpu":torch.cuda.get_device_name(device),"torch":str(torch.__version__),
        "numpy":str(core.np.__version__),"experiment":"16-bit Mod3解耦的数据需求趋势复核，不估计精确相变点",
        "frozen_sources":{p.name:core.sha(p) for p in sources},
        "cross_length_boundary":"骨干与训练协议相同；输出随prefix数量增至32，跨长度不声称初始权重完全相同。"}
    path = out / "MANIFEST.json"
    if path.exists() and json.loads(path.read_text(encoding="utf-8")) != manifest:
        raise RuntimeError("已有协议不同，不覆盖旧结果")
    core.atomic_json(path,manifest)
    frozen = out / "source"
    frozen.mkdir(exist_ok=True)
    for source in sources:
        target = frozen / source.name
        if target.exists() and core.sha(target) != core.sha(source):
            raise RuntimeError("冻结源码不同")
        if not target.exists():
            shutil.copy2(source,target)
    verification = core.preflight(device)
    core.atomic_json(out / "VERIFICATION.json",verification)
    print("核心核验通过："+json.dumps(verification,ensure_ascii=False),flush=True)
    torch.cuda.empty_cache()
    deadline = time.monotonic()+args.hours*3600
    statuses=[]
    for n in reversed(cfg["counts"]):
        for data_seed in cfg["data_seeds"]:
            if time.monotonic() >= deadline:
                break
            result = core.run_group(out,cfg,data_seed,n,device,deadline)
            statuses.append({"n":n,"data_seed":data_seed,"status":result["status"],
                             "step":result["step"],"seconds":result["seconds"]})
            core.atomic_json(out / "RUN_STATUS.json",statuses)
            torch.cuda.empty_cache()
        else:
            continue
        break
    analyze.analyze(out)
    print("16-bit本轮结束："+json.dumps(statuses,ensure_ascii=False),flush=True)


if __name__ == "__main__":
    main()
