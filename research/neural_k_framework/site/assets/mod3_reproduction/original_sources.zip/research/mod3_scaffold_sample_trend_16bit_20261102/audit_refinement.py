"""独立核验非2次幂样本档，并合并展示过渡区；不重训旧点。"""
import ctypes
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE.parent/"mod3_scaffold_sample_trend_20261102"),str(HERE.parents[1]/".venv-gpu/Lib/site-packages")]
import numpy as np
import analyze


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(out):
    manifest=read(out/"MANIFEST.json")
    cfg=manifest["config"]
    for name,expected in manifest["frozen_sources"].items():
        assert sha(out/"source"/name)==expected
    verification=read(out/"VERIFICATION.json")
    assert verification["graph_eager_max_weight_error"]<2e-5
    assert verification["restored_step_max_weight_error"]<1e-7
    whole={ds:np.random.default_rng(ds).permutation(1<<cfg["bits"]).astype(np.uint64) for ds in cfg["data_seeds"]}
    jobs,raw=[],{}
    max_error=0.
    for path in out.glob("data*_n*/result.json"):
        result=read(path)
        assert result["status"]=="complete" and result["step"]==cfg["max_steps"]
        assert result["n"] in cfg["counts"]
        jobs.append(result)
        ids=whole[result["data_seed"]]
        assert hashlib.sha256(ids.tobytes()).hexdigest()==result["data_ids_sha256"]
        with np.load(path.parent/"data_ids.npz",allow_pickle=False) as data:
            np.testing.assert_array_equal(data["train"],ids[:result["n"]])
            np.testing.assert_array_equal(data["test"],ids[len(ids)//2:])
            assert len(np.unique(data["train"]))==result["n"]
            assert np.intersect1d(data["train"],data["test"]).size==0
        with np.load(path.parent/"forward_audit.npz",allow_pickle=False) as data:
            error=float(np.max(np.abs(data["gpu_logits"]-data["numpy_logits"])))
            assert data["gpu_logits"].shape[-1]==2*cfg["bits"] and error<.002
        assert abs(error-result["numpy_final_forward_max_error"])<1e-12
        max_error=max(max_error,error)
        for row in result["rows"]:
            key=tuple(row[k] for k in ["n","data_seed","model_seed","arm","step"])
            assert key not in raw
            raw[key]=row
    assert len(jobs)==len(cfg["counts"])*len(cfg["data_seeds"])
    assert len({j["initial_weights_sha256"] for j in jobs})==1
    data=read(out/"ANALYSIS.json")
    assert len(data["summary"])==len(cfg["counts"])*2*len(cfg["stages"])
    assert len(data["pairs"])==len(cfg["counts"])*len(cfg["data_seeds"])*len(cfg["model_seeds"])*len(cfg["stages"])
    assert len({tuple(r[k] for k in ["n","arm","stage"]) for r in data["summary"]})==len(data["summary"])
    assert len({tuple(r[k] for k in ["n","data_seed","model_seed","stage"]) for r in data["pairs"]})==len(data["pairs"])
    windows={}
    for n in cfg["counts"]:
        for ds in cfg["data_seeds"]:
            for ms in cfg["model_seeds"]:
                for arm in ["direct","scaffold"]:
                    for stage in cfg["stages"]:
                        values=[raw[n,ds,ms,arm,stage-i*cfg["eval_every"]]["test_endpoint_exact"] for i in range(cfg["summary_window_points"])]
                        windows[n,ds,ms,arm,stage]=(float(np.mean(values)),min(values))
    for row in data["summary"]:
        values=[]
        success=fit=0
        for ds in cfg["data_seeds"]:
            for ms in cfg["model_seeds"]:
                value,low=windows[row["n"],ds,ms,row["arm"],row["stage"]]
                values.append(value)
                success+=low>=cfg["success_accuracy"]
                fit+=raw[row["n"],ds,ms,row["arm"],row["stage"]]["train_endpoint_bce"]<=cfg["fit_bce"]
        assert len(values)==row["trials"] and row["complete_panel"]
        assert abs(np.mean(values)-row["test_mean"])<1e-12
        assert success==row["stable_success_count"] and fit==row["endpoint_fit_count"]
    for row in data["pairs"]:
        n,ds,ms,stage=[row[k] for k in ["n","data_seed","model_seed","stage"]]
        change=100*(windows[n,ds,ms,"scaffold",stage][0]-windows[n,ds,ms,"direct",stage][0])
        assert abs(change-row["test_difference_pp"])<1e-10
    final=[r for key,r in raw.items() if key[-1]==cfg["max_steps"]]
    audit_result={"groups":len(jobs),"models":len(final),"max_numpy_forward_error":max_error,
        "data_disjoint_and_nested":True,"window_statistics_recomputed":True,
        "initial_hash":jobs[0]["initial_weights_sha256"],
        "data_hashes":{str(j["data_seed"]):j["data_ids_sha256"] for j in jobs},
        "train_exact_100_count":sum(r["train_endpoint_exact"]==1. for r in final),
        "train_bce_below_0_001_count":sum(r["train_endpoint_bce"]<=cfg["fit_bce"] for r in final),
        "seconds":sum(j["seconds"] for j in jobs)}
    return cfg,data,audit_result


def merge_and_audit(here):
    coarse,refined=here/"results",here/"results_refined"
    cfg1,data1,audit1=audit(coarse)
    cfg2,data2,audit2=audit(refined)
    excluded={"counts","refinement_source_sha256"}
    assert {k:v for k,v in cfg1.items() if k not in excluded}=={k:v for k,v in cfg2.items() if k not in excluded}
    assert not set(cfg1["counts"])&set(cfg2["counts"])
    assert audit1["initial_hash"]==audit2["initial_hash"] and audit1["data_hashes"]==audit2["data_hashes"]
    merged={key:data1[key]+data2[key] for key in ["summary","pairs","jobs"]}
    merged["scope"]="旧两端仅保留不重跑；新增2500/3000/3500/5000/6000/7000过渡区。2份数据各3个初始化，不拟合精确相变点。"
    output=here/"results_combined"
    output.mkdir(exist_ok=True)
    (output/"ANALYSIS.json").write_text(json.dumps(merged,ensure_ascii=False,indent=2),encoding="utf-8")
    (output/"AUDIT.json").write_text(json.dumps({"coarse":audit1,"refined":audit2,
        "source_analysis_sha256":[sha(coarse/"ANALYSIS.json"),sha(refined/"ANALYSIS.json")],
        "audit_source_sha256":sha(Path(__file__))},ensure_ascii=False,indent=2),encoding="utf-8")
    analyze.write_csv(output/"summary.csv",merged["summary"])
    analyze.write_csv(output/"paired_changes.csv",merged["pairs"])
    plot_focus(output,cfg1,merged)
    print(json.dumps([r for r in merged["summary"] if r["stage"]==16000 and 2048<=r["n"]<=8192],ensure_ascii=False,indent=2))
    return merged


def plot_focus(out,cfg,data):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.family"]=["Microsoft YaHei","DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"]=False
    fig,axes=plt.subplots(1,2,figsize=(13,4.9),layout="constrained")
    colors={"direct":"#B64B37","scaffold":"#2075AA"}
    names={"direct":"无解耦：6次均值","scaffold":"解耦：6次均值"}
    for arm in colors:
        rows=sorted([r for r in data["summary"] if r["arm"]==arm and r["stage"]==16000 and 2048<=r["n"]<=8192],key=lambda r:r["n"])
        ns=[r["n"] for r in rows]
        axes[0].plot(ns,[100*r["test_mean"] for r in rows],"o-",color=colors[arm],lw=2,label=names[arm])
        for ds in cfg["data_seeds"]:
            values=[]
            for n in ns:
                group=[r for r in data["pairs"] if r["n"]==n and r["stage"]==16000 and r["data_seed"]==ds]
                key="direct_accuracy" if arm=="direct" else "scaffold_accuracy"
                values.append(100*np.mean([r[key] for r in group]))
            axes[0].plot(ns,values,color=colors[arm],lw=.8,ls="--",alpha=.4)
    ns=sorted({r["n"] for r in data["pairs"] if 2048<=r["n"]<=8192})
    for stage in cfg["stages"]:
        values=[np.mean([r["test_difference_pp"] for r in data["pairs"] if r["n"]==n and r["stage"]==stage]) for n in ns]
        axes[1].plot(ns,values,"o-",label=f"{stage}步")
    axes[0].set(title="1.6万步固定窗口的测试准确率",ylabel="最终余数exact准确率 (%)",ylim=(20,102))
    axes[1].set(title="解耦组减去无解耦组",ylabel="配对平均改善 (百分点)")
    axes[1].axhline(0,color="black",lw=.8)
    for ax in axes:
        ax.set(xlabel="训练输入样本数",xlim=(1900,8400))
        ax.set_xticks([2000,3000,4000,5000,6000,7000,8000])
        ax.grid(alpha=.2)
        ax.legend(fontsize=8,loc="best")
    fig.suptitle("16-bit Mod3：只加密过渡区\n左图细线为各数据组的3 seed均值，不是置信区间",fontsize=12)
    fig.savefig(out/"transition_refined.png",dpi=160)
    plt.close(fig)


if __name__=="__main__":
    merge_and_audit(HERE)
