"""只加密仍有信息量的过渡区，不重跑饱和端或小样本底部。"""
import ctypes
import os
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/"mod3_scaffold_sample_trend_20261102"
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG",":4096:8")
os.environ.setdefault("OPENBLAS_NUM_THREADS","2")
sys.path[:0]=[str(BASE),str(HERE),str(HERE.parents[1]/".venv-gpu/Lib/site-packages")]
print("16-bit过渡区加密：只追加2500/3000/3500/5000/6000/7000",flush=True)

import argparse
import json
import shutil
import time
import torch
import experiment as core
import analyze


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--hours",type=float,default=1.)
    args=parser.parse_args()
    parent=HERE/"results"
    manifest=json.loads((parent/"MANIFEST.json").read_text(encoding="utf-8"))
    previous=json.loads((parent/"ANALYSIS.json").read_text(encoding="utf-8"))
    if len(previous["jobs"])!=10 or any(j["status"]!="complete" for j in previous["jobs"]):
        raise RuntimeError("原粗扫尚未完整结束，不并发启动")
    for path,key in [(core.__file__,"source_sha256"),(core.legacy.__file__,"legacy_sha256"),
                     (core.legacy.old.__file__,"model_source_sha256")]:
        if core.sha(path)!=manifest["config"][key]:
            raise RuntimeError("原训练核心发生变化")
    if core.sha(analyze.__file__)!=core.sha(parent/"source/analyze.py"):
        raise RuntimeError("原统计核心发生变化")
    if not torch.cuda.is_available():
        raise RuntimeError("需要GPU1，不回退CPU")
    if str(torch.__version__)!=manifest["torch"]:
        raise RuntimeError("PyTorch版本与粗扫不同，不混用")
    cfg={**manifest["config"],"counts":[2500,3000,3500,5000,6000,7000],
         "refinement_source_sha256":core.sha(__file__)}
    order=[3000,6000,2500,3500,5000,7000]
    out=HERE/"results_refined"
    out.mkdir(exist_ok=True)
    sources=[Path(__file__),HERE/"audit_refinement.py",Path(core.__file__),Path(analyze.__file__),
             Path(core.legacy.__file__),Path(core.legacy.old.__file__)]
    protocol={**manifest,"config":cfg,"run_order":order,
        "gpu":torch.cuda.get_device_name(1),"torch":str(torch.__version__),"numpy":str(core.np.__version__),
        "frozen_sources":{p.name:core.sha(p) for p in sources},
        "reason":"用户要求只补信息量仍高的过渡区；不追加12000/16000样本，不重跑已有两端。16000仍仅指每次训练步数。",
        "coarse_manifest_sha256":core.sha(parent/"MANIFEST.json")}
    path=out/"MANIFEST.json"
    if path.exists() and json.loads(path.read_text(encoding="utf-8"))!=protocol:
        raise RuntimeError("已有加密协议不同，不覆盖")
    core.atomic_json(path,protocol)
    frozen=out/"source"
    frozen.mkdir(exist_ok=True)
    for source in sources:
        target=frozen/source.name
        if target.exists() and core.sha(target)!=core.sha(source):
            raise RuntimeError("加密冻结源码不符")
        if not target.exists():
            shutil.copy2(source,target)
    device=torch.device("cuda:1")
    torch.cuda.set_device(device)
    torch.set_num_threads(4)
    torch.set_deterministic_debug_mode("error")
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    torch.backends.cudnn.benchmark=False
    core.atomic_json(out/"VERIFICATION.json",core.preflight(device))
    deadline=time.monotonic()+args.hours*3600
    statuses=[]
    for n in order:
        for seed in cfg["data_seeds"]:
            if time.monotonic()>=deadline or (out/"STOP_AFTER_GROUP").exists():
                break
            result=core.run_group(out,cfg,seed,n,device,deadline)
            statuses.append({"n":n,"data_seed":seed,"status":result["status"],"step":result["step"],"seconds":result["seconds"]})
            core.atomic_json(out/"RUN_STATUS.json",statuses)
            torch.cuda.empty_cache()
        else:
            continue
        break
    analyze.analyze(out)
    if len(statuses)==12 and all(r["status"]=="complete" for r in statuses):
        import audit_refinement
        audit_refinement.merge_and_audit(HERE)
    print("过渡区本轮结束："+json.dumps(statuses,ensure_ascii=False),flush=True)


if __name__=="__main__":
    main()
