"""加载现有GPU依赖；不安装或修改环境。"""
import ctypes
import os
from pathlib import Path
import runpy
import sys

HERE = Path(__file__).resolve().parent
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")
sys.path[:0] = [str(HERE), str(HERE.parents[1] / ".venv-gpu/Lib/site-packages")]
print("加载14-bit Mod3配对训练环境", flush=True)
sys.argv[0] = str(HERE / "experiment.py")
runpy.run_path(sys.argv[0], run_name="__main__")
