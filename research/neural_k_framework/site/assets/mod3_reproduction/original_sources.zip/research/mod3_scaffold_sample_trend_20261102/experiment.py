"""粗扫解耦监督是否降低Mod3的数据需求；不精确拟合相变点。"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import shutil
import sys
import time

import numpy as np
import torch
from torch.nn import functional as F

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
OLD_DIR = REPO / "research/ca_phase_transition"
sys.path.insert(0, str(OLD_DIR))
import experiment_mod3_endpoint_scaffold_matched_bce as legacy


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True).encode()).hexdigest()


def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    for attempt in range(20):
        try:
            temporary.replace(path)
            return
        except PermissionError:
            if attempt == 19:
                raise
            time.sleep(.1)


def model_hash(model):
    value = hashlib.sha256()
    for name, tensor in model.state_dict().items():
        value.update(name.encode())
        value.update(tensor.detach().cpu().numpy().tobytes())
    return value.hexdigest()


def dataset(bits, seed, model_bits):
    ids = np.random.default_rng(seed).permutation(1 << bits).astype(np.uint64)
    active = legacy.old.ids_to_bits(ids, bits)
    x = np.pad(active, ((0, 0), (model_bits-bits, 0)))
    y = legacy.prefix_labels(active)
    # 独立整数公式核验全部样本、全部前缀，不仅检查最后的标签。
    for j in range(bits):
        truth = ((ids >> (bits-1-j)) % 3).astype(np.int64)
        np.testing.assert_array_equal(y[:, 2*j:2*j+2], legacy.old.remainders_to_bits(truth))
    split = len(ids)//2
    assert len(np.unique(ids)) == len(ids)
    return {"ids": ids, "x": x, "y": y, "split": split,
            "ids_sha256": hashlib.sha256(ids.tobytes()).hexdigest()}


def make_model(cfg, device):
    seeds = tuple(cfg["model_seeds"])*2
    return legacy.old.BatchedIndependentMLP(cfg["model_bits"], 2*cfg["bits"], cfg["width"],
        cfg["layers"], seeds, "gelu", 1e-5).to(device=device, dtype=torch.float32)


def objective(logits, labels, aux_weight):
    bce = F.softplus(-logits*(2*labels[None]-1)).mean(1)
    # 最终任务权重始终为1，辅助均值单独加权，避免输出数量改变主任务权重。
    return bce[:, -2:].mean(-1) + aux_weight*bce[:, :-2].mean(-1)


def capture(model, optimizer, x, y, index, aux_weight):
    weights = {k: v.detach().clone() for k, v in model.state_dict().items()}
    saved = copy.deepcopy(optimizer.state_dict()) if optimizer.state else None
    count = model.output_bias.shape[0]

    def step():
        optimizer.zero_grad(set_to_none=True)
        z = model(x[index][None].expand(count, -1, -1))
        loss = objective(z, y[index], aux_weight)
        loss.sum().backward()
        optimizer.step()
        return loss

    stream = torch.cuda.Stream()
    stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(stream):
        for _ in range(3):
            step()
    torch.cuda.current_stream().wait_stream(stream)
    graph = torch.cuda.CUDAGraph()
    optimizer.zero_grad(set_to_none=True)
    with torch.cuda.graph(graph):
        loss = step()
    legacy.restore_inplace(model, optimizer, weights, saved)
    torch.cuda.synchronize()
    return graph, loss


def numpy_forward(weights, x, layers):
    h = np.broadcast_to(np.asarray(x, dtype=np.float64), (weights["output_bias"].shape[0], *x.shape))
    erf = np.vectorize(math.erf, otypes=[float])
    for i in range(layers):
        w = weights[f"hidden_weights.{i}"].numpy().astype(np.float64)
        b = weights[f"hidden_biases.{i}"].numpy().astype(np.float64)
        h = h @ w.transpose(0, 2, 1) + b[:, None]
        h = .5*h*(1+erf(h/math.sqrt(2)))
        h = (h-h.mean(-1, keepdims=True))/np.sqrt(h.var(-1, keepdims=True)+1e-5)
        h = h*weights[f"norm_weights.{i}"].numpy()[:, None] + weights[f"norm_biases.{i}"].numpy()[:, None]
    return h @ weights["output_weight"].numpy().astype(np.float64).transpose(0, 2, 1) + weights["output_bias"].numpy()[:, None]


def preflight(device):
    cfg = {"bits": 6, "model_bits": 8, "width": 32, "layers": 3, "model_seeds": [0, 1]}
    data = dataset(6, 71, 8)
    x, y = [torch.tensor(data[k], device=device) for k in ("x", "y")]
    model = make_model(cfg, device)
    assert all(torch.equal(p[:2], p[2:]) for p in model.parameters())
    weight = torch.tensor([0., 0., 1., 1.], device=device)
    z = model(x[:16][None].expand(4, -1, -1))
    raw = F.binary_cross_entropy_with_logits(z, y[None, :16].expand_as(z), reduction="none")
    expected = raw[:, :, -2:].mean((1, 2)) + weight*raw[:, :, :-2].mean((1, 2))
    torch.testing.assert_close(objective(z, y[:16], weight), expected)
    grads = torch.autograd.grad(objective(z, y[:16], weight).sum(), z)[0]
    assert torch.count_nonzero(grads[:2, :, :-2]) == 0
    torch.testing.assert_close(grads[:2, :, -2:], grads[2:, :, -2:])
    eager, graphed = copy.deepcopy(model), copy.deepcopy(model)
    la, lb = torch.tensor(.001, device=device), torch.tensor(.001, device=device)
    oa, ob = legacy.optimizer_for(eager, la), legacy.optimizer_for(graphed, lb)
    index = torch.arange(16, device=device)
    graph, _ = capture(graphed, ob, x, y, index, weight)
    for k in range(12):
        index.copy_((torch.arange(16, device=device)+k*3)%64)
        la.fill_(.001*min(1., (k+1)/10)); lb.copy_(la)
        oa.zero_grad(set_to_none=True)
        objective(eager(x[index][None].expand(4, -1, -1)), y[index], weight).sum().backward()
        oa.step()
        graph.replay()
    graph_error = max(float((v-eager.state_dict()[k]).detach().abs().max()) for k, v in graphed.state_dict().items())
    assert graph_error < 2e-5, graph_error
    saved = legacy.cpu_tree(graphed.state_dict())
    opt = legacy.cpu_tree(ob.state_dict())
    graph.replay()
    after = legacy.cpu_tree(graphed.state_dict())
    legacy.restore_inplace(graphed, ob, saved, opt)
    graph.replay()
    resume_error = max(float((v-graphed.state_dict()[k].cpu()).abs().max()) for k, v in after.items())
    assert resume_error < 1e-7, resume_error
    independent = numpy_forward(legacy.cpu_tree(eager.state_dict()), data["x"][:16], 3)
    with torch.no_grad():
        actual = eager(x[:16][None].expand(4, -1, -1)).cpu().numpy()
    forward_error = float(np.max(np.abs(actual-independent)))
    assert forward_error < 2e-5, forward_error
    model.zero_grad(set_to_none=True)
    objective(model(x[:16][None].expand(4, -1, -1)), y[:16], weight)[0].backward()
    assert all(torch.count_nonzero(p.grad[1:]) == 0 for p in model.parameters())
    return {"all_prefix_integer_labels": True, "paired_initialization": True,
            "equal_endpoint_loss_weight": True, "direct_aux_gradient_zero": True,
            "independent_models": True, "graph_eager_max_weight_error": graph_error,
            "restored_step_max_weight_error": resume_error, "numpy_forward_max_error": forward_error}


def run_group(out, cfg, data_seed, n, device, deadline):
    folder = out/f"data{data_seed}_n{n}"
    folder.mkdir(exist_ok=True)
    data = dataset(cfg["bits"], data_seed, cfg["model_bits"])
    signature = digest({"config": cfg, "n": n, "data_seed": data_seed, "data_hash": data["ids_sha256"]})
    report = folder/"result.json"
    if report.exists():
        prior = json.loads(report.read_text(encoding="utf-8"))
        if prior["signature"] != signature:
            raise RuntimeError("已有分组协议不同，禁止覆写")
        if prior["status"] == "complete":
            return prior
    start_time = time.monotonic()
    count = len(cfg["model_seeds"])
    model = make_model(cfg, device)
    assert all(torch.equal(p[:count], p[count:]) for p in model.parameters())
    initial_hash = model_hash(model)
    model_count = 2*count
    x, y = [torch.tensor(data[k], device=device) for k in ("x", "y")]
    train_x, train_y = x[:n], y[:n]
    test_x, test_y = x[data["split"]:], y[data["split"]:]
    gen = torch.Generator(device=device).manual_seed(cfg["batch_seed"]+data_seed+n)
    index = torch.zeros(cfg["batch_size"], device=device, dtype=torch.long)
    weight = torch.tensor([0.]*count + [cfg["aux_lambda"]]*count, device=device)
    lr = torch.tensor(cfg["learning_rate"], device=device)
    optimizer = legacy.optimizer_for(model, lr)
    checkpoint = folder/"checkpoint.pt"
    saved = None
    if checkpoint.exists():
        saved = torch.load(checkpoint, map_location="cpu", weights_only=False)
        if saved["signature"] != signature:
            raise RuntimeError("检查点协议不符")
        model.load_state_dict(saved["weights"])
        gen.set_state(saved["batch_rng"])
        result = saved["result"]
    else:
        np.savez_compressed(folder/"data_ids.npz", train=data["ids"][:n], test=data["ids"][data["split"]:])
        result = {"signature": signature, "status": "running", "step": 0, "seconds": 0.,
                  "n": n, "data_seed": data_seed, "initial_weights_sha256": initial_hash,
                  "data_ids_sha256": data["ids_sha256"], "rows": [],
                  "parameters_per_model": sum(p.numel() for p in model.parameters())//model_count}
    prior_seconds = result["seconds"]
    graph, loss = capture(model, optimizer, train_x, train_y, index, weight)
    if saved is not None:
        legacy.restore_inplace(model, optimizer, saved["weights"], saved["optimizer"])
        del saved

    def save():
        result["seconds"] = prior_seconds+time.monotonic()-start_time
        legacy.atomic_torch(checkpoint, {"signature": signature, "weights": legacy.cpu_tree(model.state_dict()),
            "optimizer": legacy.cpu_tree(optimizer.state_dict()), "batch_rng": gen.get_state().cpu(), "result": result})
        atomic_json(report, result)

    def evaluate():
        train = legacy.evaluate(model, train_x, train_y, chunk=cfg["eval_chunk"])
        test = legacy.evaluate(model, test_x, test_y, chunk=cfg["eval_chunk"])
        for i in range(model_count):
            result["rows"].append({"n": n, "data_seed": data_seed, "model_seed": cfg["model_seeds"][i%count],
                "arm": "direct" if i<count else "scaffold", "step": result["step"],
                **{"train_"+k: v for k, v in train[i].items()}, **{"test_"+k: v for k, v in test[i].items()}})
        detail = " | ".join(f"{arm}: trainBCE={np.mean([v['endpoint_bce'] for v in train[a:b]]):.3g}, test={np.mean([v['endpoint_exact'] for v in test[a:b]]):.2%}"
                            for arm, a, b in [("direct",0,count),("scaffold",count,model_count)])
        print(f"data={data_seed} n={n} step={result['step']} | {detail}", flush=True)
        atomic_json(report, result)

    try:
        if result["step"] == 0:
            evaluate()
        for step in range(result["step"]+1, cfg["max_steps"]+1):
            if step%250 == 1 and time.monotonic() >= deadline:
                result["status"] = "budget_limited"
                break
            torch.randint(n, (cfg["batch_size"],), generator=gen, device=device, out=index)
            lr.fill_(cfg["learning_rate"]*min(1., step/cfg["warmup_steps"]))
            graph.replay()
            result["step"] = step
            if step in (100,500) or step%cfg["eval_every"] == 0:
                if not bool(torch.isfinite(loss).all()):
                    raise RuntimeError("训练loss非有限，不丢弃失败seed")
                evaluate()
            if step in cfg["checkpoints"]:
                save()
        else:
            result["status"] = "complete"
        chosen = np.r_[np.arange(8), np.arange(data["split"], data["split"]+8)]
        weights = legacy.cpu_tree(model.state_dict())
        independent = numpy_forward(weights, data["x"][chosen], cfg["layers"])
        with torch.no_grad():
            actual = model(x[torch.tensor(chosen, device=device)][None].expand(model_count,-1,-1)).cpu().numpy()
        error = float(np.max(np.abs(actual-independent)))
        result["numpy_final_forward_max_error"] = error
        if error > .002:
            raise RuntimeError(f"独立前向误差异常：{error}")
        np.savez_compressed(folder/"forward_audit.npz", ids=data["ids"][chosen], gpu_logits=actual, numpy_logits=independent)
    except Exception as error:
        result["status"], result["error"] = "failed", repr(error)
        raise
    finally:
        save()
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--hours", type=float, default=1.5)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    device = torch.device("cuda:1")
    if not torch.cuda.is_available():
        raise RuntimeError("需要GPU1，不回退CPU")
    torch.cuda.set_device(device)
    torch.set_num_threads(4)
    torch.set_deterministic_debug_mode("error")
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    out = args.out or HERE/("smoke" if args.smoke else "results")
    out.mkdir(parents=True, exist_ok=True)
    cfg = {"bits": 14, "model_bits": 30, "width": 1024, "layers": 3,
           "counts": [256,1024,4096,8192], "data_seeds": [202611020,202611021], "model_seeds": [0,1,2],
           "batch_seed": 314159, "batch_size": 512, "learning_rate": .001, "warmup_steps":10,
           "aux_lambda":1., "max_steps":16000, "checkpoints":[8000,16000], "stages":[4000,8000,16000],
           "summary_window_points":3, "success_accuracy":.99, "fit_bce":.001,
           "eval_every":1000, "eval_chunk":512, "dtype":"float32", "weight_decay":0., "dropout":0.,
           "objective":"L_endpoint + lambda * mean_BCE(auxiliary_prefixes); lambda=0 or 1",
           "batch_sampling":"固定512，所有n均有放回抽样；同组配对模型共享batch",
           "train_split":"全空间一半作为嵌套训练池；另一半固定测试；辅助标签不进入测试输入",
           "source_sha256":sha(__file__), "legacy_sha256":sha(legacy.__file__), "model_source_sha256":sha(legacy.old.__file__)}
    if args.smoke:
        cfg.update(bits=6, model_bits=8, width=32, counts=[16,32], data_seeds=[71], model_seeds=[0,1],
                   max_steps=20, checkpoints=[10,20], stages=[10,20], eval_every=10, batch_size=16, eval_chunk=16,
                   summary_window_points=1)
    manifest = {"config":cfg,"gpu":torch.cuda.get_device_name(device),"torch":str(torch.__version__),
                "experiment":"Mod3解耦是否降低输入样本需求：粗粒度趋势测试，不估计精确相变点"}
    path = out/"MANIFEST.json"
    if path.exists() and json.loads(path.read_text(encoding="utf-8")) != manifest:
        raise RuntimeError("总协议不同，不覆盖历史结果")
    atomic_json(path, manifest)
    source = out/"source"
    source.mkdir(exist_ok=True)
    for original in [Path(__file__),HERE/"launch.py",HERE/"analyze.py",Path(legacy.__file__),Path(legacy.old.__file__)]:
        target = source/original.name
        if target.exists() and sha(target) != sha(original):
            raise RuntimeError("冻结源码不符")
        if not target.exists():
            shutil.copy2(original,target)
    verification = preflight(device)
    atomic_json(out/"VERIFICATION.json",verification)
    print("核验通过："+json.dumps(verification,ensure_ascii=False),flush=True)
    torch.cuda.empty_cache()
    deadline = time.monotonic()+args.hours*3600
    statuses=[]
    for n in reversed(cfg["counts"]):
        for seed in cfg["data_seeds"]:
            if time.monotonic() >= deadline:
                break
            result = run_group(out,cfg,seed,n,device,deadline)
            statuses.append({"data_seed":seed,"n":n,"status":result["status"],"step":result["step"],"seconds":result["seconds"]})
            atomic_json(out/"RUN_STATUS.json",statuses)
            torch.cuda.empty_cache()
        else:
            continue
        break
    import analyze
    analyze.analyze(out)
    print("本轮结束："+json.dumps(statuses,ensure_ascii=False),flush=True)


if __name__ == "__main__":
    main()
