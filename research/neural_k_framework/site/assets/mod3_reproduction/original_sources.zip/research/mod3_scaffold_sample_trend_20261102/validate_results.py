"""不启动训练，独立重算窗口、配对差异和数据隔离。"""
import ctypes
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / ".venv-gpu/Lib/site-packages"))
import numpy as np


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    roots=[HERE/"results",HERE/"results_midpoint"]
    cfg=read(roots[0]/"MANIFEST.json")["config"]
    other=read(roots[1]/"MANIFEST.json")["config"]
    ignore={"counts","extension_source_sha256"}
    assert {k:v for k,v in cfg.items() if k not in ignore}=={k:v for k,v in other.items() if k not in ignore}
    jobs=[]
    lookup={}
    datasets={}
    max_forward_error=0.
    for root in roots:
        for name in ["experiment.py","analyze.py"]:
            assert sha(root/"source"/name)==sha(HERE/name)
        for name,key in [("experiment_mod3_endpoint_scaffold_matched_bce.py","legacy_sha256"),
                         ("experiment_mod3_small_data_grokking.py","model_source_sha256")]:
            assert sha(root/"source"/name)==cfg[key]
            assert sha(HERE.parent/"ca_phase_transition"/name)==cfg[key]
        verification=read(root/"VERIFICATION.json")
        assert verification["graph_eager_max_weight_error"]<2e-5
        assert verification["restored_step_max_weight_error"]<1e-7
        for path in root.glob("data*_n*/result.json"):
            job=read(path)
            assert job["status"]=="complete" and job["step"]==16000
            jobs.append(job)
            with np.load(path.parent/"data_ids.npz",allow_pickle=False) as data:
                train,test=data["train"].copy(),data["test"].copy()
            assert len(train)==job["n"] and len(test)==8192
            assert len(np.unique(train))==len(train) and len(np.unique(test))==len(test)
            assert np.intersect1d(train,test).size==0
            assert np.max(train)<(1<<14) and np.max(test)<(1<<14)
            datasets.setdefault(job["data_seed"],[]).append((job["n"],train,test,job["data_ids_sha256"]))
            with np.load(path.parent/"forward_audit.npz",allow_pickle=False) as data:
                error=float(np.max(np.abs(data["gpu_logits"]-data["numpy_logits"])))
            assert abs(error-job["numpy_final_forward_max_error"])<1e-12 and error<.002
            max_forward_error=max(max_forward_error,error)
            for row in job["rows"]:
                key=tuple(row[k] for k in ["n","data_seed","model_seed","arm","step"])
                assert key not in lookup
                lookup[key]=row
    assert len(jobs)==10 and len({j["initial_weights_sha256"] for j in jobs})==1
    for rows in datasets.values():
        rows.sort(key=lambda x:x[0])
        full=rows[-1]
        whole=np.concatenate((full[1],full[2]))
        assert len(np.unique(whole))==(1<<14)
        assert hashlib.sha256(whole.tobytes()).hexdigest()==full[3]
        for n,train,test,data_hash in rows:
            np.testing.assert_array_equal(train,full[1][:n])
            np.testing.assert_array_equal(test,full[2])
            assert data_hash==full[3]
    combined=read(HERE/"results_combined/ANALYSIS.json")
    assert len(combined["summary"])==30 and len(combined["pairs"])==90
    windows={}
    for n in [256,1024,2048,4096,8192]:
        for ds in cfg["data_seeds"]:
            for ms in cfg["model_seeds"]:
                for arm in ["direct","scaffold"]:
                    for stage in cfg["stages"]:
                        values=[lookup[n,ds,ms,arm,stage-i*1000]["test_endpoint_exact"] for i in range(3)]
                        windows[n,ds,ms,arm,stage]=float(np.mean(values))
    for row in combined["summary"]:
        values=[windows[row["n"],ds,ms,row["arm"],row["stage"]] for ds in cfg["data_seeds"] for ms in cfg["model_seeds"]]
        assert row["complete_panel"] and row["trials"]==6
        assert abs(float(np.mean(values))-row["test_mean"])<1e-12
        successes=fitted=0
        for ds in cfg["data_seeds"]:
            for ms in cfg["model_seeds"]:
                sequence=[lookup[row["n"],ds,ms,row["arm"],row["stage"]-i*1000]["test_endpoint_exact"] for i in range(3)]
                successes+=min(sequence)>=cfg["success_accuracy"]
                fitted+=lookup[row["n"],ds,ms,row["arm"],row["stage"]]["train_endpoint_bce"]<=cfg["fit_bce"]
        assert successes==row["stable_success_count"] and fitted==row["endpoint_fit_count"]
    for row in combined["pairs"]:
        n,ds,ms,stage=[row[k] for k in ["n","data_seed","model_seed","stage"]]
        difference=100*(windows[n,ds,ms,"scaffold",stage]-windows[n,ds,ms,"direct",stage])
        assert abs(difference-row["test_difference_pp"])<1e-10
    details=[]
    for n in [256,1024,2048,4096,8192]:
        for ds in cfg["data_seeds"]:
            direct=np.mean([windows[n,ds,ms,"direct",16000] for ms in cfg["model_seeds"]])*100
            scaffold=np.mean([windows[n,ds,ms,"scaffold",16000] for ms in cfg["model_seeds"]])*100
            details.append({"n":n,"data_seed":ds,"direct_percent":float(direct),"scaffold_percent":float(scaffold),
                            "difference_pp":float(scaffold-direct)})
    final_rows=[row for key,row in lookup.items() if key[-1]==16000]
    audit={"completed_groups":len(jobs),"trained_models":len(final_rows),"all_nested_splits_disjoint":True,
        "identical_initialization_across_conditions":True,"summary_and_pairs_recomputed":True,
        "max_independent_forward_error":max_forward_error,"final_train_exact_100_count":sum(r["train_endpoint_exact"]==1. for r in final_rows),
        "final_train_bce_below_0_001_count":sum(r["train_endpoint_bce"]<=.001 for r in final_rows),
        "group_execution_seconds":sum(j["seconds"] for j in jobs),"by_dataset":details}
    (HERE/"results_combined/AUDIT.json").write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(audit,ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
