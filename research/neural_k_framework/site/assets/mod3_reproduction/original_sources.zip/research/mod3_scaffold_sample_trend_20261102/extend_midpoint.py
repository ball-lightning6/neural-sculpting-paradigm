"""仅补2048样本这一档，保留原四档结果，不搜索精确相变点。"""
import ctypes
import os
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")
sys.path[:0] = [str(HERE), str(HERE.parents[1] / ".venv-gpu/Lib/site-packages")]
print("加载2048样本桥接档；原四档结果不变", flush=True)

import json
import time
import torch
import experiment as ex
import analyze


def main():
    original = HERE / "results"
    manifest = json.loads((original / "MANIFEST.json").read_text(encoding="utf-8"))
    if manifest["config"]["source_sha256"] != ex.sha(ex.__file__):
        raise RuntimeError("原训练源码已变化")
    if manifest["config"]["legacy_sha256"] != ex.sha(ex.legacy.__file__) or manifest["config"]["model_source_sha256"] != ex.sha(ex.legacy.old.__file__):
        raise RuntimeError("原模型或优化器辅助源码已变化")
    if ex.sha(original / "source/analyze.py") != ex.sha(analyze.__file__):
        raise RuntimeError("原分析源码已变化")
    original_analysis = json.loads((original / "ANALYSIS.json").read_text(encoding="utf-8"))
    if len(original_analysis["jobs"]) != 8 or any(j["status"] != "complete" for j in original_analysis["jobs"]):
        raise RuntimeError("先等待原四档全部结束，不并发启动")
    cfg = {**manifest["config"], "counts": [2048], "extension_source_sha256": ex.sha(__file__)}
    out = HERE / "results_midpoint"
    out.mkdir(exist_ok=True)
    extended = {**manifest, "config": cfg,
                "reason": "初扫4096接近饱和、1024未高泛化，补一个粗粒度中间档；不继续定位精确点。"}
    path = out / "MANIFEST.json"
    if path.exists() and json.loads(path.read_text(encoding="utf-8")) != extended:
        raise RuntimeError("桥接档已有不同协议，不覆写")
    ex.atomic_json(path, extended)
    source = out / "source"
    source.mkdir(exist_ok=True)
    for old in [Path(__file__), Path(ex.__file__), Path(analyze.__file__), Path(ex.legacy.__file__), Path(ex.legacy.old.__file__)]:
        target = source / old.name
        if target.exists() and ex.sha(target) != ex.sha(old):
            raise RuntimeError("冻结源码不同")
        if not target.exists():
            shutil.copy2(old, target)
    device = torch.device("cuda:1")
    if not torch.cuda.is_available():
        raise RuntimeError("需要GPU1，不回退CPU")
    torch.cuda.set_device(device)
    torch.set_num_threads(4)
    torch.set_deterministic_debug_mode("error")
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    ex.atomic_json(out / "VERIFICATION.json", ex.preflight(device))
    statuses = []
    deadline = time.monotonic() + 1800
    for seed in cfg["data_seeds"]:
        if time.monotonic() >= deadline:
            break
        result = ex.run_group(out, cfg, seed, 2048, device, deadline)
        statuses.append({"n":2048,"data_seed":seed,"status":result["status"],"step":result["step"]})
        ex.atomic_json(out / "RUN_STATUS.json", statuses)
        torch.cuda.empty_cache()
    extra = analyze.analyze(out)
    combined = {key: original_analysis[key] + extra[key] for key in ["summary","pairs","jobs"]}
    combined["scope"] = "原四档加一档2048桥接；每档2份数据各3个初始化，不估计精确相变点。"
    hashes = {j["initial_weights_sha256"] for j in combined["jobs"]}
    if len(hashes) != 1:
        raise RuntimeError("桥接档与原档的初始化不一致")
    for seed in cfg["data_seeds"]:
        if len({j["data_ids_sha256"] for j in combined["jobs"] if j["data_seed"] == seed}) != 1:
            raise RuntimeError("桥接档没有沿用同一嵌套数据池")
    merged = HERE / "results_combined"
    merged.mkdir(exist_ok=True)
    ex.atomic_json(merged / "ANALYSIS.json", combined)
    ex.atomic_json(merged / "PROVENANCE.json", {
        "original_analysis_sha256":ex.sha(original / "ANALYSIS.json"),
        "midpoint_analysis_sha256":ex.sha(out / "ANALYSIS.json"),
        "extension_source_sha256":ex.sha(__file__)})
    analyze.write_csv(merged / "summary.csv", combined["summary"])
    analyze.write_csv(merged / "paired_changes.csv", combined["pairs"])
    plot_cfg = {**cfg, "counts": sorted(manifest["config"]["counts"] + [2048])}
    analyze.plot(merged, plot_cfg, combined["summary"], combined["pairs"])
    print("桥接档执行结束：" + json.dumps(statuses, ensure_ascii=False) + "；合并结果在：" + str(merged), flush=True)


if __name__ == "__main__":
    main()
