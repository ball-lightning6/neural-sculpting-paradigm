"""按预先固定的预算窗口汇总配对趋势，不选择最佳测试时刻。"""
import csv
import json
from pathlib import Path

import numpy as np


def write_csv(path, rows):
    if not rows:
        return
    keys = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def analyze(out):
    manifest = json.loads((out/"MANIFEST.json").read_text(encoding="utf-8"))
    cfg = manifest["config"]
    raw, jobs = [], []
    for path in sorted(out.glob("data*_n*/result.json")):
        job = json.loads(path.read_text(encoding="utf-8"))
        jobs.append({k: job.get(k) for k in ["n","data_seed","status","step","seconds","initial_weights_sha256",
                                          "data_ids_sha256","numpy_final_forward_max_error"]})
        raw.extend(job["rows"])
    lookup = {(r["n"],r["data_seed"],r["model_seed"],r["arm"],r["step"]):r for r in raw}
    windows=[]
    for n in cfg["counts"]:
        for ds in cfg["data_seeds"]:
            for ms in cfg["model_seeds"]:
                for arm in ["direct","scaffold"]:
                    for stage in cfg["stages"]:
                        steps = [stage-i*cfg["eval_every"] for i in range(cfg["summary_window_points"])]
                        values = [lookup.get((n,ds,ms,arm,s)) for s in steps]
                        if any(v is None for v in values):
                            continue
                        end = values[0]
                        accuracy = [v["test_endpoint_exact"] for v in values]
                        windows.append({"n":n,"data_seed":ds,"model_seed":ms,"arm":arm,"stage":stage,
                            "window_test_accuracy":float(np.mean(accuracy)), "window_min_test_accuracy":min(accuracy),
                            "stable_success":min(accuracy)>=cfg["success_accuracy"],
                            "train_bce_end":end["train_endpoint_bce"],"train_exact_end":end["train_endpoint_exact"],
                            "test_bce_end":end["test_endpoint_bce"],
                            "train_aux_bce_end":(end["train_all_output_bce"]*cfg["bits"]-end["train_endpoint_bce"])/(cfg["bits"]-1)})
    expected=len(cfg["data_seeds"])*len(cfg["model_seeds"])
    summary=[]
    for n in cfg["counts"]:
        for stage in cfg["stages"]:
            for arm in ["direct","scaffold"]:
                group=[r for r in windows if r["n"]==n and r["stage"]==stage and r["arm"]==arm]
                if not group:
                    continue
                summary.append({"n":n,"stage":stage,"arm":arm,"trials":len(group),"complete_panel":len(group)==expected,
                    "test_mean":float(np.mean([r["window_test_accuracy"] for r in group])),
                    "test_min":min(r["window_test_accuracy"] for r in group),"test_max":max(r["window_test_accuracy"] for r in group),
                    "stable_success_count":sum(r["stable_success"] for r in group),
                    "endpoint_fit_count":sum(r["train_bce_end"]<=cfg["fit_bce"] for r in group),
                    "train_bce_mean":float(np.mean([r["train_bce_end"] for r in group])),
                    "train_aux_bce_mean":float(np.mean([r["train_aux_bce_end"] for r in group]))})
    pairs=[]
    for direct in windows:
        if direct["arm"]!="direct":
            continue
        related=[r for r in windows if r["arm"]=="scaffold" and all(r[k]==direct[k] for k in ["n","data_seed","model_seed","stage"])]
        if not related:
            continue
        scaffold=related[0]
        pairs.append({**{k:direct[k] for k in ["n","data_seed","model_seed","stage"]},
            "test_difference_pp":100*(scaffold["window_test_accuracy"]-direct["window_test_accuracy"]),
            "direct_accuracy":direct["window_test_accuracy"],"scaffold_accuracy":scaffold["window_test_accuracy"],
            "both_endpoint_fit":direct["train_bce_end"]<=cfg["fit_bce"] and scaffold["train_bce_end"]<=cfg["fit_bce"]})
    hashes={j["initial_weights_sha256"] for j in jobs}
    if len(hashes)>1:
        raise RuntimeError("跨条件初始权重不一致")
    for ds in cfg["data_seeds"]:
        if len({j["data_ids_sha256"] for j in jobs if j["data_seed"]==ds})>1:
            raise RuntimeError("同一数据种子的嵌套数据池不一致")
    write_csv(out/"trajectory.csv",raw)
    write_csv(out/"window_results.csv",windows)
    write_csv(out/"summary.csv",summary)
    write_csv(out/"paired_changes.csv",pairs)
    result={"summary":summary,"pairs":pairs,"jobs":jobs,
            "scope":f"每档{len(cfg['data_seeds'])}份数据、每份{len(cfg['model_seeds'])}个初始化；不把初始化次数当独立数据份数。报告固定晚期窗口，不选择最好时刻，不拟合精确相变点。"}
    (out/"ANALYSIS.json").write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    plot(out,cfg,summary,pairs)
    print(json.dumps([r for r in summary if r["stage"]==cfg["max_steps"]],ensure_ascii=False,indent=2),flush=True)
    return result


def plot(out,cfg,summary,pairs):
    if not summary:
        return
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.family"]=["Microsoft YaHei","DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"]=False
    fig,axes=plt.subplots(1,3,figsize=(15,4.6),layout="constrained")
    colors={"direct":"#B64B37","scaffold":"#2075AA"}
    labels={"direct":"仅最终余数","scaffold":"加前缀监督"}
    styles=[":","--","-"][-len(cfg["stages"]):]
    for stage,style in zip(cfg["stages"],styles):
        for arm in colors:
            group=sorted([r for r in summary if r["stage"]==stage and r["arm"]==arm],key=lambda r:r["n"])
            if not group:
                continue
            x=[r["n"] for r in group]
            label=f"{labels[arm]}，{stage}步"
            axes[0].plot(x,[100*r["test_mean"] for r in group],marker="o",linestyle=style,color=colors[arm],label=label)
            axes[1].plot(x,[max(1e-12,r["train_bce_mean"]) for r in group],marker="o",linestyle=style,color=colors[arm])
        xs,means=[],[]
        for n in cfg["counts"]:
            group=[r["test_difference_pp"] for r in pairs if r["n"]==n and r["stage"]==stage]
            if group:
                xs.append(n); means.append(float(np.mean(group)))
        axes[2].plot(xs,means,"o"+style,label=f"{stage}步")
    axes[0].set(title="固定晚期窗口的测试准确率",ylabel="最终余数exact准确率 (%)",ylim=(0,102))
    axes[0].axhline(99,color="gray",alpha=.4,linewidth=.8)
    axes[0].legend(fontsize=7,loc="lower right")
    axes[1].set(title="最终任务的训练BCE",ylabel="各次训练末端BCE的均值",yscale="log")
    axes[2].set(title="解耦组减去无解耦组",ylabel="配对准确率变化 (百分点)")
    axes[2].axhline(0,color="black",linewidth=.8)
    axes[2].legend(fontsize=8)
    for ax in axes:
        ax.set_xscale("log",base=2)
        ax.set_xticks(cfg["counts"],labels=[str(n) for n in cfg["counts"]])
        ax.set_xlabel("训练输入样本数")
        ax.grid(alpha=.2)
    fig.suptitle(f"{cfg['bits']}-bit Mod3：配对数据量趋势，不估计精确相变点",fontsize=13)
    fig.savefig(out/"sample_requirement_trend.png",dpi=150)
    plt.close(fig)
