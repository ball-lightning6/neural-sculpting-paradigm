"""30bit Mod3配对重训：比较有无DFA监督时最终两位的BCE。

复用旧Mod3的有限宽MLP，不运行SMC。两组都是60输出的相同网络，
direct仅监督末两位，dfa监督全部60位；未使用的direct输出不影响前向。
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
import random
import signal
import time

import numpy as np
import torch
from torch.nn import functional as F

import experiment_mod3_small_data_grokking as old

ROOT = Path(__file__).resolve().parents[2]


class Config:
    INPUT_BITS = 30
    TRAIN_COUNT = 524_288
    VALIDATION_COUNT = 16_384
    TEST_COUNT = 32_768
    DATA_SEED = 20260820
    MODEL_SEEDS = (0, 1, 2)
    BATCH_SEED = 314159
    HIDDEN_SIZE = 1024
    HIDDEN_LAYERS = 3
    BATCH_SIZE = 512
    LEARNING_RATE = 1e-3
    WARMUP_STEPS = 10
    MAX_STEPS = 100_000
    EVAL_EVERY = 500
    FULL_TRAIN_EVERY = 10_000
    CHECKPOINT_EVERY = 5_000
    TRAIN_MONITOR_COUNT = 16_384
    EVAL_CHUNK = 1024
    GENERALIZATION_THRESHOLD = 0.999
    GENERALIZATION_CONFIRMATIONS = 3
    DEVICE = 'cuda:1'
    RESULT_DIR = ROOT / 'tmp/mod3_endpoint_scaffold_matched_bce_20260913'
    RESUME = True


def settings():
    return {k.lower(): str(v) if isinstance(v, Path) else v
            for k,v in vars(Config).items() if k.isupper()}


def log(message):
    line = time.strftime('%Y-%m-%d %H:%M:%S')+' | '+message
    print(line, flush=True)
    if Config.RESULT_DIR.exists():
        with (Config.RESULT_DIR/'run.log').open('a',encoding='utf-8') as stream:
            stream.write(line+'\n')


def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    temporary.replace(path)


def cpu_tree(value):
    if isinstance(value,torch.Tensor):
        return value.detach().cpu().clone()
    if isinstance(value,dict):
        return {k:cpu_tree(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):
        return type(value)(cpu_tree(v) for v in value)
    return value


def atomic_torch(path,value):
    temporary=path.with_suffix('.tmp.pt')
    torch.save(value,temporary)
    for attempt in range(4):
        try:
            temporary.replace(path)
            return
        except PermissionError:
            if attempt==3:
                raise
            time.sleep(.2*(attempt+1))


def prefix_labels(x):
    state=np.zeros(len(x),dtype=np.int64)
    labels=[]
    for bit in x.T.astype(np.int64):
        state=(state*2+bit)%3
        labels.extend(((state>>1)&1,state&1))
    return np.stack(labels,axis=1).astype(np.float32)


def make_data():
    n=Config.TRAIN_COUNT+Config.VALIDATION_COUNT+Config.TEST_COUNT
    ids=np.asarray(random.Random(Config.DATA_SEED).sample(range(1<<Config.INPUT_BITS),n),dtype=np.uint64)
    x=old.ids_to_bits(ids,Config.INPUT_BITS)
    y=prefix_labels(x)
    np.testing.assert_array_equal(y[:,-2:],old.remainders_to_bits(ids%3))
    assert len(np.unique(ids))==n
    a,b=Config.TRAIN_COUNT,Config.TRAIN_COUNT+Config.VALIDATION_COUNT
    return {'ids':ids,'x':x,'y':y,'ranges':{'train':(0,a),'validation':(a,b),'test':(b,n)}}


def make_model(bits=None,width=None,seeds=None):
    bits=Config.INPUT_BITS if bits is None else bits
    seeds=Config.MODEL_SEEDS if seeds is None else seeds
    return old.BatchedIndependentMLP(bits,bits*2,Config.HIDDEN_SIZE if width is None else width,
        Config.HIDDEN_LAYERS,tuple(seeds)*2,'gelu',1e-5)


def objective(logits,targets):
    per_bit=F.softplus(-logits*(2*targets[None]-1)).mean(1)
    count=logits.shape[0]//2
    # 模型轴求和，不能将单模型梯度额外除以模型数。
    return torch.cat((per_bit[:count,-2:].mean(-1),per_bit[count:].mean(-1)))


def optimizer_for(model,lr):
    return torch.optim.AdamW(model.parameters(),lr=lr,betas=(.9,.999),eps=1e-8,
                            weight_decay=0.,capturable=True,foreach=False)


def restore_inplace(model,optimizer,weights,state=None):
    model.load_state_dict(weights)
    for i,parameter in enumerate(model.parameters()):
        for key,value in optimizer.state[parameter].items():
            if state is None:
                value.zero_()
            else:
                value.copy_(state['state'][i][key].to(value.device))


def capture(model,optimizer,x,y,index):
    before={k:v.detach().clone() for k,v in model.state_dict().items()}
    saved=copy.deepcopy(optimizer.state_dict()) if optimizer.state else None
    stream=torch.cuda.Stream()
    stream.wait_stream(torch.cuda.current_stream())

    def step():
        optimizer.zero_grad(set_to_none=True)
        batch=x[index]
        logits=model(batch[None].expand(model.output_bias.shape[0],-1,-1))
        loss=objective(logits,y[index])
        loss.sum().backward()
        optimizer.step()
        return loss

    with torch.cuda.stream(stream):
        for _ in range(3):
            step()
    torch.cuda.current_stream().wait_stream(stream)
    graph=torch.cuda.CUDAGraph()
    optimizer.zero_grad(set_to_none=True)
    with torch.cuda.graph(graph):
        loss=step()
    restore_inplace(model,optimizer,before,saved)
    torch.cuda.synchronize()
    return graph,loss


@torch.no_grad()
def evaluate(model,x,y,chunk=None):
    chunk=Config.EVAL_CHUNK if chunk is None else chunk
    m=model.output_bias.shape[0]
    totals=torch.zeros((m,7),device=x.device,dtype=torch.float64)
    for start in range(0,len(x),chunk):
        xx,yy=x[start:start+chunk],y[start:start+chunk]
        z=model(xx[None].expand(m,-1,-1))
        bce=F.softplus(-z*(2*yy[None]-1))
        correct=(z>0)==(yy[None]>.5)
        end=z[:,:,-2:]*(2*yy[None,:,-2:]-1)
        totals[:,0]+=bce[:,:,-2:].sum((1,2),dtype=torch.float64)/2
        totals[:,1]+=bce.mean(-1).sum(1,dtype=torch.float64)
        totals[:,2]+=correct[:,:,-2:].all(-1).sum(1)
        totals[:,3]+=correct[:,:,-2:].sum((1,2))/2
        totals[:,4]+=correct.all(-1).sum(1)
        totals[:,5]+=end.sum((1,2),dtype=torch.float64)/2
        totals[:,6]+=end.square().sum((1,2),dtype=torch.float64)/2
    values=(totals/len(x)).cpu().numpy()
    fields=('endpoint_bce','all_output_bce','endpoint_exact','endpoint_bit_accuracy',
            'trace_exact','endpoint_margin_mean','endpoint_margin_second_moment')
    result=[dict(zip(fields,map(float,row))) for row in values]
    for row in result:
        row['endpoint_margin_sd']=max(0.,row['endpoint_margin_second_moment']-row['endpoint_margin_mean']**2)**.5
    return result


def preflight(device='cuda:1'):
    torch.set_num_threads(4)
    torch.cuda.set_device(device)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    ids=np.arange(64,dtype=np.uint64)
    x=old.ids_to_bits(ids,6)
    y=prefix_labels(x)
    for j in range(6):
        np.testing.assert_array_equal(y[:,2*j:2*j+2],old.remainders_to_bits((ids>>(5-j))%3))
    xx,yy=torch.tensor(x,device=device),torch.tensor(y,device=device)
    m=make_model(bits=6,width=32,seeds=(0,1)).to(device)
    paired=all(torch.equal(p[0],p[2]) and torch.equal(p[1],p[3]) for p in m.parameters())
    assert paired
    z=m(xx[None].expand(4,-1,-1))
    expected=F.binary_cross_entropy_with_logits(z,yy[None].expand_as(z),reduction='none')
    target=torch.cat((expected[:2,:,-2:].mean((1,2)),expected[2:].mean((1,2))))
    assert torch.allclose(objective(z,yy),target,atol=2e-7,rtol=2e-6)
    changed=yy.clone(); changed[:,:-2]=1-changed[:,:-2]
    assert torch.equal(objective(z,yy)[:2],objective(z,changed)[:2])
    grad=torch.autograd.grad(objective(z,yy).sum(),z)[0]
    assert torch.count_nonzero(grad[:2,:,:-2])==0
    count=m.output_bias.shape[0]
    a,b=copy.deepcopy(m),copy.deepcopy(m)
    la=torch.tensor(.001,device=device); lb=la.clone()
    oa,ob=optimizer_for(a,la),optimizer_for(b,lb)
    index=torch.arange(16,device=device)
    graph,_=capture(b,ob,xx,yy,index)
    for step in range(10):
        index.copy_((torch.arange(16,device=device)+step*3)%64)
        oa.zero_grad(set_to_none=True)
        objective(a(xx[index][None].expand(count,-1,-1)),yy[index]).sum().backward()
        oa.step(); graph.replay()
    error=max(float((v-a.state_dict()[k]).abs().max()) for k,v in b.state_dict().items())
    assert error<2e-5,error
    weights={k:v.detach().clone() for k,v in b.state_dict().items()}
    saved=cpu_tree(ob.state_dict())
    graph.replay(); after={k:v.detach().clone() for k,v in b.state_dict().items()}
    restore_inplace(b,ob,weights,saved); graph.replay()
    resume_error=max(float((v-after[k]).abs().max()) for k,v in b.state_dict().items())
    assert resume_error<1e-7,resume_error
    metrics=evaluate(a,xx,yy,chunk=13)
    full=evaluate(a,xx,yy,chunk=64)
    chunk_error=max(abs(left[key]-right[key]) for left,right in zip(metrics,full) for key in left)
    assert chunk_error<1e-5,chunk_error
    # 不同模型之间没有共享训练参数或归一化统计。
    a.zero_grad(set_to_none=True)
    objective(a(xx[:16][None].expand(count,-1,-1)),yy[:16])[0].backward()
    assert all(torch.count_nonzero(p.grad[1:])==0 for p in a.parameters())
    result={'prefix_targets':'all64inputs_all6prefixes_passed','paired_initialization':paired,
            'bce_and_auxiliary_isolation':'passed','independent_models':'passed',
            'graph_eager_max_error':error,'resume_max_error':resume_error,'evaluation_chunk_error':chunk_error}
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
    return result


@torch.no_grad()
def save_selected(model,index,path,metadata):
    weights={k:v[index:index+1].detach().cpu().clone() for k,v in model.state_dict().items()}
    atomic_torch(path,{'weights':weights,'metadata':metadata})


def checkpoint(model,optimizer,generator,state,signature):
    atomic_torch(Config.RESULT_DIR/'checkpoint.pt',{'weights':cpu_tree(model.state_dict()),
        'optimizer':cpu_tree(optimizer.state_dict()),'rng':generator.get_state().cpu(),
        'state':state,'signature':signature})
    atomic_json(Config.RESULT_DIR/'state.json',state)


def main():
    if not torch.cuda.is_available():
        raise RuntimeError('正式实验需要CUDA，不自动改用CPU。')
    torch.set_num_threads(4)
    torch.cuda.set_device(Config.DEVICE)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    out=Config.RESULT_DIR; out.mkdir(parents=True,exist_ok=True)
    scientific=settings()
    for key in ('max_steps','result_dir','resume'):
        scientific.pop(key,None)
    scientific.update(dtype='float32',tf32=False,weight_decay=0.,dropout=0.,
        optimizer='AdamW beta=(0.9,0.999), eps=1e-8',
        direct_objective='mean BCE over last two outputs',
        dfa_objective=f'mean BCE over all {2*Config.INPUT_BITS} outputs, including the same last two outputs',
        model='old.BatchedIndependentMLP: GELU then LayerNorm after each hidden linear',
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        model_source_sha256=hashlib.sha256(Path(old.__file__).read_bytes()).hexdigest())
    signature=hashlib.sha256(json.dumps(scientific,sort_keys=True).encode()).hexdigest()
    protocol=out/'protocol.json'
    if protocol.exists():
        assert json.loads(protocol.read_text(encoding='utf-8'))['signature']==signature,'旧目录的科学配置不同'
    else:
        atomic_json(protocol,{'scientific':scientific,'signature':signature,'initial_max_steps':Config.MAX_STEPS,
            'timestamp':time.strftime('%Y-%m-%d %H:%M:%S'),'gpu':torch.cuda.get_device_name(),
            'torch':torch.__version__,'cuda':torch.version.cuda,
            'stop':'预算上限，或三个配对direct均到达scaffold稳定99.9%时的全训练集endpoint BCE并保持三次评估',
            'test_policy':'独立test仅在结束后读取，验证集用于阶段定位与停止'})
    data=make_data()
    np.savez_compressed(out/'dataset_ids.npz',ids=data['ids'],train_count=Config.TRAIN_COUNT,
                        validation_count=Config.VALIDATION_COUNT,data_seed=Config.DATA_SEED)
    atomic_json(out/'data_audit.json',{'all_inputs_unique':True,'endpoint_matches_integer_mod3':True,
        'ids_sha256':hashlib.sha256(data['ids'].tobytes()).hexdigest(),'ranges':data['ranges']})
    x,y=torch.from_numpy(data['x']).to(Config.DEVICE),torch.from_numpy(data['y']).to(Config.DEVICE)
    a,b=data['ranges']['validation']; va,vb=x[a:b],y[a:b]
    train_x,train_y=x[:Config.TRAIN_COUNT],y[:Config.TRAIN_COUNT]
    model=make_model().to(Config.DEVICE)
    seed_count=len(Config.MODEL_SEEDS); count=2*seed_count
    assert all(torch.equal(p[:seed_count],p[seed_count:]) for p in model.parameters())
    lr=torch.tensor(Config.LEARNING_RATE,device=Config.DEVICE)
    optimizer=optimizer_for(model,lr)
    generator=torch.Generator(device=Config.DEVICE).manual_seed(Config.BATCH_SEED)
    state={'step':0,'train_seconds':0.,'evaluation_seconds':0.,'history':[],
           'generalized_streak':[0]*count,'generalized_reference':{},'first_99':{},
           'matched_streak':0,'status':'running'}
    point=out/'checkpoint.pt'
    if Config.RESUME and point.exists():
        saved=torch.load(point,map_location='cpu',weights_only=True)
        assert saved['signature']==signature
        model.load_state_dict(saved['weights']); optimizer.load_state_dict(saved['optimizer'])
        optimizer.param_groups[0]['lr']=lr
        generator.set_state(saved['rng']); state=saved['state']; state['status']='running'
        log(f"恢复 step={state['step']:,}")
    elif not (out/'initial_weights.pt').exists():
        atomic_torch(out/'initial_weights.pt',cpu_tree(model.state_dict()))
    index=torch.arange(Config.BATCH_SIZE,device=Config.DEVICE)%Config.TRAIN_COUNT
    graph,live_loss=capture(model,optimizer,train_x,train_y,index)
    stop_requested=[False]
    def interrupt(signum,frame):
        stop_requested[0]=True
    signal.signal(signal.SIGINT,interrupt)
    if hasattr(signal,'SIGTERM'):
        signal.signal(signal.SIGTERM,interrupt)

    def record(force_full=False):
        begin=time.perf_counter()
        step=state['step']
        monitor=evaluate(model,train_x[:Config.TRAIN_MONITOR_COUNT],train_y[:Config.TRAIN_MONITOR_COUNT])
        validation=evaluate(model,va,vb)
        new_threshold=[i for i in range(count) if str(i) not in state['first_99'] and validation[i]['endpoint_exact']>=.99]
        new_stable=[]
        for i in range(count):
            good=validation[i]['endpoint_exact']>=Config.GENERALIZATION_THRESHOLD
            state['generalized_streak'][i]=state['generalized_streak'][i]+1 if good else 0
            if state['generalized_streak'][i]>=Config.GENERALIZATION_CONFIRMATIONS and str(i) not in state['generalized_reference']:
                new_stable.append(i)
        approximate_match=all(str(seed_count+i) in state['generalized_reference'] and
            monitor[i]['endpoint_bce']<=state['generalized_reference'][str(seed_count+i)]['train']['endpoint_bce']*1.05
            for i in range(seed_count))
        full_needed=force_full or step%Config.FULL_TRAIN_EVERY==0 or bool(new_threshold or new_stable) or approximate_match
        train=evaluate(model,train_x,train_y) if full_needed else None
        entry={'step':step,'train_seconds':state['train_seconds'],'monitor':monitor,'validation':validation,'full_train':train}
        state['history'].append(entry)
        for i in new_threshold:
            item={'step':step,'train':train[i],'validation':validation[i]}
            state['first_99'][str(i)]=item
            save_selected(model,i,out/f'first_99_model_{i}.pt',item)
        for i in new_stable:
            item={'step':step,'train':train[i],'validation':validation[i]}
            state['generalized_reference'][str(i)]=item
            save_selected(model,i,out/f'stable_999_model_{i}.pt',item)
        matched=bool(train) and all(str(seed_count+i) in state['generalized_reference'] and
            train[i]['endpoint_bce']<=state['generalized_reference'][str(seed_count+i)]['train']['endpoint_bce']
            for i in range(seed_count))
        state['matched_streak']=state['matched_streak']+1 if matched else 0
        state['evaluation_seconds']+=time.perf_counter()-begin
        for arm in range(2):
            selection=range(arm*seed_count,(arm+1)*seed_count)
            train_read=train if train else monitor
            log(f"{'direct' if arm==0 else 'dfa':6s} step={step:,} | "
                f"{'全训练' if train else '训练监测'}endpoint BCE="+str([round(train_read[i]['endpoint_bce'],8) for i in selection])+
                ' | 验证exact='+str([round(100*validation[i]['endpoint_exact'],3) for i in selection]))
        atomic_json(out/'state.json',state)
        return state['matched_streak']>=3

    log(f"开始配对Mod3 | {torch.cuda.get_device_name()} | train={Config.TRAIN_COUNT:,} | 2组x{seed_count} seeds")
    try:
        if not state['history']:
            record(force_full=True)
        while state['step']<Config.MAX_STEPS and not stop_requested[0]:
            end=min(Config.MAX_STEPS,((state['step']//Config.EVAL_EVERY)+1)*Config.EVAL_EVERY)
            torch.cuda.synchronize(); begin=time.perf_counter()
            for step in range(state['step']+1,end+1):
                if step<=Config.WARMUP_STEPS+1:
                    lr.fill_(Config.LEARNING_RATE*min(step/Config.WARMUP_STEPS,1.))
                torch.randint(Config.TRAIN_COUNT,(Config.BATCH_SIZE,),generator=generator,device=Config.DEVICE,out=index)
                graph.replay()
                state['step']=step
                if stop_requested[0]:
                    break
            torch.cuda.synchronize(); elapsed=time.perf_counter()-begin
            state['train_seconds']+=elapsed
            if not torch.isfinite(live_loss).all():
                raise RuntimeError('训练出现非有限loss')
            reached=record(force_full=state['step']==Config.MAX_STEPS or stop_requested[0])
            log(f"PROGRESS {state['step']:,}/{Config.MAX_STEPS:,} | 累计训练{state['train_seconds']/60:.1f}分钟 | "
                f"累计评估{state['evaluation_seconds']/60:.1f}分钟 | 最近{Config.EVAL_EVERY/elapsed:.2f} step/s")
            if state['step']%Config.CHECKPOINT_EVERY==0 or reached or stop_requested[0]:
                checkpoint(model,optimizer,generator,state,signature)
            if reached:
                state['status']='matched_scaffold_loss'
                break
        else:
            state['status']='paused' if stop_requested[0] else 'budget_completed'
        if stop_requested[0]:
            state['status']='paused'
        if state['status']=='running':
            state['status']='budget_completed'
    finally:
        checkpoint(model,optimizer,generator,state,signature)
    if state['status']!='paused':
        full_train=evaluate(model,train_x,train_y)
        a,b=data['ranges']['test']; test=evaluate(model,x[a:b],y[a:b])
        final={'step':state['step'],'status':state['status'],'full_train':full_train,'test':test,
               'seed_order':list(Config.MODEL_SEEDS)*2,'arm_order':['direct']*seed_count+['dfa']*seed_count,
               'generalized_reference':state['generalized_reference'],'first_99':state['first_99'],
               'train_seconds':state['train_seconds'],'evaluation_seconds':state['evaluation_seconds']}
        atomic_json(out/'final.json',final)
        atomic_torch(out/'final_weights.pt',cpu_tree(model.state_dict()))
        log('FINAL '+json.dumps(final,ensure_ascii=False))
    log(f'结果目录：{out}')


if __name__=='__main__':
    main()
