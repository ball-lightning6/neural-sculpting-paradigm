"""检验“更少数据能否帮助 endpoint-only Mod 3 逃离优化平台”。

任务：30-bit 二进制整数 -> 2-bit (value mod 3)，不提供 DFA 中间状态。

实验包含两部分：
1. 固定嵌套训练集，从 256 扫到 524,288 个样本；
2. 小数据预热后切换到 524,288 个正确样本，并用随机标签预热作对照。

所有条件共享数据排列；同一 model seed 在所有条件下严格同初始化。课程切换时
默认清空 Adam moments，只保留网络权重，以区分“学到的表示”与优化器惯性。
结果支持滚动 checkpoint 和提高 MAX_STEPS 后直接续训。
"""

from __future__ import annotations

import csv
import json
import math
import random
import shutil
import time
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class Config:
    # =========================
    # 任务与数据
    # =========================
    INPUT_BITS = 30
    FIXED_TRAIN_COUNTS = (
        256, 512, 1_024, 2_048, 4_096, 8_192,
        16_384, 32_768, 65_536, 131_072, 524_288,
    )
    PROBE_COUNT = 16_384
    DATA_SEED = 20260820
    RANDOM_LABEL_SEED = 20260821

    # 小数据预热恰好执行这些 step；第 SWITCH_STEP + 1 步切换到全量正确数据。
    CURRICULUM_SWITCH_STEP = 5_000
    CURRICULA = (
        {"name": "correct_1k_to_full", "pre_count": 1_024, "pre_labels": "correct"},
        {"name": "correct_8k_to_full", "pre_count": 8_192, "pre_labels": "correct"},
        {"name": "random_8k_to_full", "pre_count": 8_192, "pre_labels": "random"},
    )
    RESET_ADAM_STATE_ON_SWITCH = True

    # =========================
    # 模型与训练
    # =========================
    MODEL_SEEDS = (0, 1, 2)
    HIDDEN_SIZE = 1024
    HIDDEN_LAYER_COUNT = 3
    ACTIVATION = "gelu"
    LAYERNORM_EPS = 1e-5

    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
    LEARNING_RATE = 1e-3
    WARMUP_STEPS = 10
    WEIGHT_DECAY = 0.0
    BATCH_SIZE = 512
    MAX_STEPS = 100_000
    TRAIN_ORDER_SEED = 314159
    FULL_BATCH_WHEN_COUNT_LEQ_BATCH = True

    # 数学等价于二元 BCE，但避免正标签在大 logit 时的 float32 梯度消减。
    NUMERICALLY_STABLE_SIGNED_BCE = True

    TRAIN_EVAL_CAP = 16_384
    EVAL_BATCH_SIZE = 2048
    LATE_EVAL_INTERVAL = 2_000
    LOG_INTERVAL_STEPS = 1_000
    CHECKPOINT_INTERVAL_STEPS = 10_000

    RESULT_DIR = Path("/root/results_mod3_small_data_grokking")
    RESUME = True
    OVERWRITE_EXISTING = False
    PACKAGE_RESULTS = True
    SMOKE_TEST = False


@dataclass(frozen=True)
class ConditionSpec:
    name: str
    kind: str
    pre_count: int
    post_count: int
    switch_step: int | None
    pre_labels: str

    def state_at(self, step: int) -> tuple[int, str, str]:
        if self.kind == "fixed":
            return self.post_count, "correct", "fixed"
        if self.switch_step is None:
            raise ValueError(f"课程条件缺少 switch_step：{self.name}")
        if step <= self.switch_step:
            return self.pre_count, self.pre_labels, "prewarm"
        return self.post_count, "correct", "post_switch"


@dataclass(frozen=True)
class RuntimeConfig:
    input_bits: int
    fixed_train_counts: tuple[int, ...]
    probe_count: int
    data_seed: int
    random_label_seed: int
    curriculum_switch_step: int
    conditions: tuple[ConditionSpec, ...]
    reset_adam_state_on_switch: bool
    model_seeds: tuple[int, ...]
    hidden_size: int
    hidden_layer_count: int
    activation: str
    layernorm_eps: float
    device: str
    learning_rate: float
    warmup_steps: int
    weight_decay: float
    batch_size: int
    max_steps: int
    train_order_seed: int
    full_batch_when_count_leq_batch: bool
    numerically_stable_signed_bce: bool
    train_eval_cap: int
    eval_batch_size: int
    late_eval_interval: int
    log_interval_steps: int
    checkpoint_interval_steps: int
    result_dir: Path
    resume: bool
    overwrite_existing: bool
    package_results: bool
    smoke_test: bool


@dataclass(frozen=True)
class ParameterBundle:
    hidden_weights: tuple[torch.Tensor, ...]
    hidden_biases: tuple[torch.Tensor, ...]
    norm_weights: tuple[torch.Tensor, ...]
    norm_biases: tuple[torch.Tensor, ...]
    output_weight: torch.Tensor
    output_bias: torch.Tensor


def make_conditions(
    fixed_counts: Sequence[int],
    curricula: Sequence[dict[str, object]],
    switch_step: int,
) -> tuple[ConditionSpec, ...]:
    full_count = max(fixed_counts)
    conditions = [
        ConditionSpec(
            name=f"fixed_{count}",
            kind="fixed",
            pre_count=int(count),
            post_count=int(count),
            switch_step=None,
            pre_labels="correct",
        )
        for count in fixed_counts
    ]
    conditions.extend(
        ConditionSpec(
            name=str(item["name"]),
            kind="curriculum",
            pre_count=int(item["pre_count"]),
            post_count=full_count,
            switch_step=switch_step,
            pre_labels=str(item["pre_labels"]),
        )
        for item in curricula
    )
    return tuple(conditions)


def build_runtime_config() -> RuntimeConfig:
    if Config.SMOKE_TEST:
        fixed_counts = (16, 32, 64)
        switch_step = 5
        curricula = (
            {"name": "correct_16_to_full", "pre_count": 16, "pre_labels": "correct"},
            {"name": "random_16_to_full", "pre_count": 16, "pre_labels": "random"},
        )
        return RuntimeConfig(
            input_bits=10,
            fixed_train_counts=fixed_counts,
            probe_count=96,
            data_seed=Config.DATA_SEED,
            random_label_seed=Config.RANDOM_LABEL_SEED,
            curriculum_switch_step=switch_step,
            conditions=make_conditions(fixed_counts, curricula, switch_step),
            reset_adam_state_on_switch=True,
            model_seeds=(0, 1),
            hidden_size=64,
            hidden_layer_count=2,
            activation=Config.ACTIVATION,
            layernorm_eps=Config.LAYERNORM_EPS,
            device=Config.DEVICE,
            learning_rate=Config.LEARNING_RATE,
            warmup_steps=3,
            weight_decay=0.0,
            batch_size=64,
            max_steps=20,
            train_order_seed=Config.TRAIN_ORDER_SEED,
            full_batch_when_count_leq_batch=True,
            numerically_stable_signed_bce=True,
            train_eval_cap=64,
            eval_batch_size=128,
            late_eval_interval=5,
            log_interval_steps=5,
            checkpoint_interval_steps=10,
            result_dir=Path(
                "research/ca_phase_transition/_smoke_mod3_small_data_grokking"
            ),
            resume=False,
            overwrite_existing=True,
            package_results=True,
            smoke_test=True,
        )

    fixed_counts = tuple(int(value) for value in Config.FIXED_TRAIN_COUNTS)
    switch_step = int(Config.CURRICULUM_SWITCH_STEP)
    return RuntimeConfig(
        input_bits=int(Config.INPUT_BITS),
        fixed_train_counts=fixed_counts,
        probe_count=int(Config.PROBE_COUNT),
        data_seed=int(Config.DATA_SEED),
        random_label_seed=int(Config.RANDOM_LABEL_SEED),
        curriculum_switch_step=switch_step,
        conditions=make_conditions(fixed_counts, Config.CURRICULA, switch_step),
        reset_adam_state_on_switch=bool(Config.RESET_ADAM_STATE_ON_SWITCH),
        model_seeds=tuple(int(value) for value in Config.MODEL_SEEDS),
        hidden_size=int(Config.HIDDEN_SIZE),
        hidden_layer_count=int(Config.HIDDEN_LAYER_COUNT),
        activation=str(Config.ACTIVATION),
        layernorm_eps=float(Config.LAYERNORM_EPS),
        device=str(Config.DEVICE),
        learning_rate=float(Config.LEARNING_RATE),
        warmup_steps=int(Config.WARMUP_STEPS),
        weight_decay=float(Config.WEIGHT_DECAY),
        batch_size=int(Config.BATCH_SIZE),
        max_steps=int(Config.MAX_STEPS),
        train_order_seed=int(Config.TRAIN_ORDER_SEED),
        full_batch_when_count_leq_batch=bool(
            Config.FULL_BATCH_WHEN_COUNT_LEQ_BATCH
        ),
        numerically_stable_signed_bce=bool(
            Config.NUMERICALLY_STABLE_SIGNED_BCE
        ),
        train_eval_cap=int(Config.TRAIN_EVAL_CAP),
        eval_batch_size=int(Config.EVAL_BATCH_SIZE),
        late_eval_interval=int(Config.LATE_EVAL_INTERVAL),
        log_interval_steps=int(Config.LOG_INTERVAL_STEPS),
        checkpoint_interval_steps=int(Config.CHECKPOINT_INTERVAL_STEPS),
        result_dir=Path(Config.RESULT_DIR),
        resume=bool(Config.RESUME),
        overwrite_existing=bool(Config.OVERWRITE_EXISTING),
        package_results=bool(Config.PACKAGE_RESULTS),
        smoke_test=False,
    )


def validate_config(cfg: RuntimeConfig) -> None:
    if tuple(sorted(set(cfg.fixed_train_counts))) != cfg.fixed_train_counts:
        raise ValueError("FIXED_TRAIN_COUNTS 必须严格递增且不能重复。")
    input_space = 1 << cfg.input_bits
    if max(cfg.fixed_train_counts) + cfg.probe_count > input_space:
        raise ValueError("最大训练池与 probe 超过完整输入空间。")
    if any(item.pre_labels not in {"correct", "random"} for item in cfg.conditions):
        raise ValueError("pre_labels 只能是 correct 或 random。")
    if cfg.activation not in {"gelu", "relu", "tanh"}:
        raise ValueError(f"未知激活函数：{cfg.activation}")


def set_global_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def ids_to_bits(ids: np.ndarray, bit_count: int) -> np.ndarray:
    shifts = np.arange(bit_count - 1, -1, -1, dtype=np.uint64)
    return ((ids[:, None] >> shifts[None, :]) & 1).astype(np.float32)


def remainders_to_bits(remainders: np.ndarray) -> np.ndarray:
    return np.stack(
        ((remainders >> 1) & 1, remainders & 1), axis=1
    ).astype(np.float32)


def make_dataset(cfg: RuntimeConfig):
    input_space = 1 << cfg.input_bits
    required = max(cfg.fixed_train_counts) + cfg.probe_count
    # 30-bit 全空间太大，不能先构造完整 permutation。
    ids = np.asarray(
        random.Random(cfg.data_seed).sample(range(input_space), required),
        dtype=np.uint64,
    )
    inputs = ids_to_bits(ids, cfg.input_bits)
    remainders = (ids % 3).astype(np.int64)
    correct_targets = remainders_to_bits(remainders)

    random_remainders = np.random.default_rng(cfg.random_label_seed).integers(
        0, 3, size=max(cfg.fixed_train_counts), dtype=np.int64
    )
    random_targets = remainders_to_bits(random_remainders)
    max_train = max(cfg.fixed_train_counts)
    return {
        "train_ids": ids[:max_train],
        "probe_ids": ids[max_train:],
        "train_x": inputs[:max_train],
        "train_y": correct_targets[:max_train],
        "train_random_y": random_targets,
        "probe_x": inputs[max_train:],
        "probe_y": correct_targets[max_train:],
    }


class BatchedIndependentMLP(nn.Module):
    def __init__(
        self,
        input_size: int,
        output_size: int,
        hidden_size: int,
        hidden_layer_count: int,
        model_seeds: Sequence[int],
        activation: str,
        layernorm_eps: float,
    ) -> None:
        super().__init__()
        self.hidden_layer_count = hidden_layer_count
        self.activation_name = activation
        self.layernorm_eps = layernorm_eps
        dimensions = [input_size]
        dimensions.extend([hidden_size] * hidden_layer_count)
        dimensions.append(output_size)

        all_hidden_weights: list[list[torch.Tensor]] = []
        all_hidden_biases: list[list[torch.Tensor]] = []
        all_norm_weights: list[list[torch.Tensor]] = []
        all_norm_biases: list[list[torch.Tensor]] = []
        all_output_weights: list[torch.Tensor] = []
        all_output_biases: list[torch.Tensor] = []
        for seed in model_seeds:
            with torch.random.fork_rng(devices=[]):
                torch.manual_seed(int(seed))
                hidden_weights = []
                hidden_biases = []
                norm_weights = []
                norm_biases = []
                for layer_index in range(hidden_layer_count):
                    linear = nn.Linear(
                        dimensions[layer_index], dimensions[layer_index + 1]
                    )
                    norm = nn.LayerNorm(
                        dimensions[layer_index + 1], eps=layernorm_eps
                    )
                    hidden_weights.append(linear.weight.detach().clone())
                    hidden_biases.append(linear.bias.detach().clone())
                    norm_weights.append(norm.weight.detach().clone())
                    norm_biases.append(norm.bias.detach().clone())
                output = nn.Linear(dimensions[-2], dimensions[-1])
                all_hidden_weights.append(hidden_weights)
                all_hidden_biases.append(hidden_biases)
                all_norm_weights.append(norm_weights)
                all_norm_biases.append(norm_biases)
                all_output_weights.append(output.weight.detach().clone())
                all_output_biases.append(output.bias.detach().clone())

        self.hidden_weights = nn.ParameterList([
            nn.Parameter(torch.stack([
                model[layer_index] for model in all_hidden_weights
            ]))
            for layer_index in range(hidden_layer_count)
        ])
        self.hidden_biases = nn.ParameterList([
            nn.Parameter(torch.stack([
                model[layer_index] for model in all_hidden_biases
            ]))
            for layer_index in range(hidden_layer_count)
        ])
        self.norm_weights = nn.ParameterList([
            nn.Parameter(torch.stack([
                model[layer_index] for model in all_norm_weights
            ]))
            for layer_index in range(hidden_layer_count)
        ])
        self.norm_biases = nn.ParameterList([
            nn.Parameter(torch.stack([
                model[layer_index] for model in all_norm_biases
            ]))
            for layer_index in range(hidden_layer_count)
        ])
        self.output_weight = nn.Parameter(torch.stack(all_output_weights))
        self.output_bias = nn.Parameter(torch.stack(all_output_biases))

    def full_bundle(self) -> ParameterBundle:
        return ParameterBundle(
            hidden_weights=tuple(self.hidden_weights),
            hidden_biases=tuple(self.hidden_biases),
            norm_weights=tuple(self.norm_weights),
            norm_biases=tuple(self.norm_biases),
            output_weight=self.output_weight,
            output_bias=self.output_bias,
        )

    def selected_bundle(self, indices: torch.Tensor) -> ParameterBundle:
        return ParameterBundle(
            hidden_weights=tuple(
                value.index_select(0, indices) for value in self.hidden_weights
            ),
            hidden_biases=tuple(
                value.index_select(0, indices) for value in self.hidden_biases
            ),
            norm_weights=tuple(
                value.index_select(0, indices) for value in self.norm_weights
            ),
            norm_biases=tuple(
                value.index_select(0, indices) for value in self.norm_biases
            ),
            output_weight=self.output_weight.index_select(0, indices),
            output_bias=self.output_bias.index_select(0, indices),
        )

    def activate(self, value: torch.Tensor) -> torch.Tensor:
        if self.activation_name == "gelu":
            return F.gelu(value)
        if self.activation_name == "relu":
            return F.relu(value)
        if self.activation_name == "tanh":
            return torch.tanh(value)
        raise ValueError(f"未知激活函数：{self.activation_name}")

    def forward_with_bundle(
        self, inputs: torch.Tensor, bundle: ParameterBundle
    ) -> torch.Tensor:
        hidden = inputs
        for layer_index in range(self.hidden_layer_count):
            hidden = torch.bmm(
                hidden, bundle.hidden_weights[layer_index].transpose(1, 2)
            )
            hidden = hidden + bundle.hidden_biases[layer_index][:, None, :]
            hidden = self.activate(hidden)
            mean = hidden.mean(dim=-1, keepdim=True)
            variance = hidden.var(dim=-1, unbiased=False, keepdim=True)
            hidden = (hidden - mean) * torch.rsqrt(
                variance + self.layernorm_eps
            )
            hidden = (
                hidden * bundle.norm_weights[layer_index][:, None, :]
                + bundle.norm_biases[layer_index][:, None, :]
            )
        return (
            torch.bmm(hidden, bundle.output_weight.transpose(1, 2))
            + bundle.output_bias[:, None, :]
        )

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return self.forward_with_bundle(inputs, self.full_bundle())


def elementwise_raw_bce(
    logits: torch.Tensor, targets: torch.Tensor, stable: bool
) -> torch.Tensor:
    if stable:
        return F.softplus(-logits * (targets * 2.0 - 1.0))
    return F.binary_cross_entropy_with_logits(logits, targets, reduction="none")


def make_model_layout(cfg: RuntimeConfig):
    expanded_seeds: list[int] = []
    indices_by_condition: dict[str, list[int]] = {}
    for condition in cfg.conditions:
        indices = []
        for seed in cfg.model_seeds:
            indices.append(len(expanded_seeds))
            expanded_seeds.append(seed)
        indices_by_condition[condition.name] = indices
    return expanded_seeds, indices_by_condition


def make_training_batch(
    cfg: RuntimeConfig,
    step: int,
    seed_count: int,
    generator: torch.Generator,
    train_x: torch.Tensor,
    train_y: torch.Tensor,
    train_random_y: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    device = train_x.device
    positions = torch.arange(cfg.batch_size, device=device)
    condition_indices = []
    condition_targets = []
    for condition in cfg.conditions:
        count, label_mode, _ = condition.state_at(step)
        if cfg.full_batch_when_count_leq_batch and count <= cfg.batch_size:
            indices = positions.remainder(count)
            mask = positions < count
        else:
            indices = torch.randint(
                0, count, (cfg.batch_size,), generator=generator, device=device
            )
            mask = torch.ones(cfg.batch_size, dtype=torch.bool, device=device)
        targets = train_y[indices] if label_mode == "correct" else train_random_y[indices]
        condition_indices.append(indices)
        condition_targets.append((targets, mask))

    indices = torch.stack(condition_indices).repeat_interleave(seed_count, dim=0)
    target_rows = torch.stack([value[0] for value in condition_targets])
    masks = torch.stack([value[1] for value in condition_targets])
    targets = target_rows.repeat_interleave(seed_count, dim=0)
    masks = masks.repeat_interleave(seed_count, dim=0)
    return train_x[indices], targets, masks


def make_eval_steps(cfg: RuntimeConfig) -> set[int]:
    steps = {
        0, 1, 2, 3, 5, 10, 20, 30, 50, 75, 100, 150, 200, 300,
        500, 750, 1000, 1500, 2000, 3000, 4000, 4500, 4900,
        cfg.curriculum_switch_step,
        cfg.curriculum_switch_step + 1,
        cfg.curriculum_switch_step + 10,
        cfg.curriculum_switch_step + 100,
        6000, 7500, 10_000, 12_500, 15_000, 17_500, 20_000,
    }
    steps.update(range(1000, min(cfg.max_steps, 20_000) + 1, 500))
    if cfg.max_steps > 20_000:
        steps.update(range(
            20_000 + cfg.late_eval_interval,
            cfg.max_steps + 1,
            cfg.late_eval_interval,
        ))
    steps.add(cfg.max_steps)
    return {step for step in steps if 0 <= step <= cfg.max_steps}


def select_eval_prefix(
    inputs: torch.Tensor,
    correct_targets: torch.Tensor,
    objective_targets: torch.Tensor,
    count: int,
    cap: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    if count <= cap:
        return inputs[:count], correct_targets[:count], objective_targets[:count]
    indices = torch.linspace(
        0, count - 1, steps=cap, device=inputs.device
    ).round().long()
    return (
        inputs.index_select(0, indices),
        correct_targets.index_select(0, indices),
        objective_targets.index_select(0, indices),
    )


@torch.no_grad()
def evaluate_group(
    model: BatchedIndependentMLP,
    model_indices: Sequence[int],
    inputs: torch.Tensor,
    targets: torch.Tensor,
    cfg: RuntimeConfig,
    keep_predictions: bool,
) -> dict[str, object]:
    device = inputs.device
    indices = torch.as_tensor(model_indices, dtype=torch.long, device=device)
    bundle = model.selected_bundle(indices)
    model_count = len(indices)
    loss_sum = torch.zeros(model_count, dtype=torch.float64, device=device)
    bit_correct = torch.zeros_like(loss_sum)
    exact_correct = torch.zeros_like(loss_sum)
    invalid_count = torch.zeros_like(loss_sum)
    margin_sum = torch.zeros_like(loss_sum)
    prediction_chunks: list[torch.Tensor] = []

    for start in range(0, len(inputs), cfg.eval_batch_size):
        end = min(start + cfg.eval_batch_size, len(inputs))
        x = inputs[start:end].unsqueeze(0).expand(model_count, -1, -1)
        y = targets[start:end].unsqueeze(0).expand(model_count, -1, -1)
        logits = model.forward_with_bundle(x, bundle)
        losses = elementwise_raw_bce(
            logits, y, cfg.numerically_stable_signed_bce
        )
        predictions = logits >= 0
        truth = y >= 0.5
        signed_margin = logits * (y * 2.0 - 1.0)
        predicted_values = (
            predictions[:, :, 0].long() * 2 + predictions[:, :, 1].long()
        )
        loss_sum += losses.sum(dim=(1, 2), dtype=torch.float64)
        bit_correct += (predictions == truth).sum(
            dim=(1, 2), dtype=torch.float64
        )
        exact_correct += (predictions == truth).all(dim=2).sum(
            dim=1, dtype=torch.float64
        )
        invalid_count += (predicted_values == 3).sum(dim=1, dtype=torch.float64)
        margin_sum += signed_margin.sum(dim=(1, 2), dtype=torch.float64)
        if keep_predictions:
            prediction_chunks.append(predictions.cpu())

    element_count = len(inputs) * targets.shape[1]
    result: dict[str, object] = {
        "raw_bce": (loss_sum / element_count).cpu().numpy(),
        "bit_accuracy": (bit_correct / element_count).cpu().numpy(),
        "exact_accuracy": (exact_correct / len(inputs)).cpu().numpy(),
        "invalid_rate": (invalid_count / len(inputs)).cpu().numpy(),
        "signed_margin": (margin_sum / element_count).cpu().numpy(),
    }
    if keep_predictions:
        result["predictions"] = torch.cat(prediction_chunks, dim=1)
    return result


def pairwise_agreement(predictions: torch.Tensor) -> tuple[float, float]:
    if predictions.shape[0] < 2:
        return 1.0, 1.0
    bit_values = []
    exact_values = []
    for first in range(predictions.shape[0]):
        for second in range(first + 1, predictions.shape[0]):
            equal = predictions[first] == predictions[second]
            bit_values.append(float(equal.float().mean().item()))
            exact_values.append(float(equal.all(dim=1).float().mean().item()))
    return float(np.mean(bit_values)), float(np.mean(exact_values))


def evaluate_all_conditions(
    model: BatchedIndependentMLP,
    cfg: RuntimeConfig,
    indices_by_condition: dict[str, list[int]],
    train_x: torch.Tensor,
    train_y: torch.Tensor,
    train_random_y: torch.Tensor,
    probe_x: torch.Tensor,
    probe_y: torch.Tensor,
    step: int,
    elapsed_seconds: float,
) -> list[dict[str, object]]:
    model.eval()
    rows: list[dict[str, object]] = []
    print(f"\n[完整评估] step={step:,}")
    for condition in cfg.conditions:
        count, label_mode, phase = condition.state_at(step)
        objective_targets_pool = (
            train_y if label_mode == "correct" else train_random_y
        )
        eval_x, eval_correct_y, eval_objective_y = select_eval_prefix(
            train_x,
            train_y,
            objective_targets_pool,
            count,
            cfg.train_eval_cap,
        )
        indices = indices_by_condition[condition.name]
        objective_train = evaluate_group(
            model, indices, eval_x, eval_objective_y, cfg, False
        )
        correct_train = evaluate_group(
            model, indices, eval_x, eval_correct_y, cfg, False
        )
        probe = evaluate_group(
            model, indices, probe_x, probe_y, cfg, True
        )
        bit_agreement, exact_agreement = pairwise_agreement(probe["predictions"])
        for local_index, seed in enumerate(cfg.model_seeds):
            rows.append({
                "step": step,
                "elapsed_seconds": elapsed_seconds,
                "condition": condition.name,
                "condition_kind": condition.kind,
                "phase": phase,
                "active_train_count": count,
                "active_label_mode": label_mode,
                "model_seed": seed,
                "objective_train_raw_bce": float(
                    objective_train["raw_bce"][local_index]
                ),
                "objective_train_bit_accuracy": float(
                    objective_train["bit_accuracy"][local_index]
                ),
                "objective_train_exact_accuracy": float(
                    objective_train["exact_accuracy"][local_index]
                ),
                "correct_train_raw_bce": float(
                    correct_train["raw_bce"][local_index]
                ),
                "correct_train_exact_accuracy": float(
                    correct_train["exact_accuracy"][local_index]
                ),
                "probe_raw_bce": float(probe["raw_bce"][local_index]),
                "probe_bit_accuracy": float(
                    probe["bit_accuracy"][local_index]
                ),
                "probe_exact_accuracy": float(
                    probe["exact_accuracy"][local_index]
                ),
                "probe_invalid_rate": float(
                    probe["invalid_rate"][local_index]
                ),
                "probe_signed_margin": float(
                    probe["signed_margin"][local_index]
                ),
                "probe_seed_pairwise_bit_agreement": bit_agreement,
                "probe_seed_pairwise_exact_agreement": exact_agreement,
            })
        print(
            f"  {condition.name:<22} | {phase:<11} | n={count:>6,} | "
            f"objective BCE={np.mean(objective_train['raw_bce']):.5g} | "
            f"train/probe exact="
            f"{np.mean(objective_train['exact_accuracy']):.3%}/"
            f"{np.mean(probe['exact_accuracy']):.3%} | "
            f"probe BCE={np.mean(probe['raw_bce']):.5g} | "
            f"agreement={exact_agreement:.3%}"
        )
    model.train()
    return rows


def reset_optimizer_slices(
    optimizer: torch.optim.Optimizer,
    model_indices: Sequence[int],
) -> None:
    if not model_indices:
        return
    for parameter in optimizer.param_groups[0]["params"]:
        state = optimizer.state.get(parameter)
        if not state:
            continue
        for key in ("exp_avg", "exp_avg_sq", "max_exp_avg_sq"):
            value = state.get(key)
            if isinstance(value, torch.Tensor) and value.ndim > 0:
                value[model_indices] = 0


def make_lr(step: int, cfg: RuntimeConfig) -> float:
    return cfg.learning_rate * min(step / max(cfg.warmup_steps, 1), 1.0)


def append_jsonl(path: Path, rows: Sequence[dict[str, object]]) -> None:
    with path.open("a", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def write_json(path: Path, value: object) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def write_csv(path: Path, rows: Sequence[dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def rows_for_condition(
    rows: Sequence[dict[str, object]], name: str
) -> list[dict[str, object]]:
    return sorted(
        (row for row in rows if str(row["condition"]) == name),
        key=lambda row: (int(row["step"]), int(row["model_seed"])),
    )


def mean_curve(
    rows: Sequence[dict[str, object]], metric: str
) -> tuple[np.ndarray, np.ndarray]:
    steps = sorted({int(row["step"]) for row in rows})
    values = [
        np.nanmean([
            float(row[metric]) for row in rows if int(row["step"]) == step
        ])
        for step in steps
    ]
    return np.asarray(steps), np.asarray(values)


def plot_fixed_sweep(
    output_dir: Path,
    rows: Sequence[dict[str, object]],
    cfg: RuntimeConfig,
) -> None:
    colors = plt.cm.viridis(np.linspace(0.03, 0.97, len(cfg.fixed_train_counts)))
    fig, axes = plt.subplots(2, 2, figsize=(15, 11))
    for color, count in zip(colors, cfg.fixed_train_counts):
        group = rows_for_condition(rows, f"fixed_{count}")
        label = f"n={count:,}"
        for axis, metric in (
            (axes[0, 0], "objective_train_raw_bce"),
            (axes[0, 1], "probe_raw_bce"),
            (axes[1, 0], "objective_train_exact_accuracy"),
            (axes[1, 1], "probe_exact_accuracy"),
        ):
            steps, values = mean_curve(group, metric)
            axis.plot(steps, values, color=color, linewidth=1.7, label=label)

    baseline = -(1 / 3) * math.log(1 / 3) - (2 / 3) * math.log(2 / 3)
    axes[0, 0].axhline(baseline, color="#777", linestyle=":", linewidth=1)
    axes[0, 1].axhline(baseline, color="#777", linestyle=":", linewidth=1)
    axes[0, 0].set_title("Endpoint-only train raw BCE")
    axes[0, 1].set_title("Held-out probe raw BCE")
    axes[1, 0].set_title("Endpoint-only train exact accuracy")
    axes[1, 1].set_title("Held-out probe exact accuracy")
    axes[0, 0].set_yscale("log")
    axes[0, 1].set_yscale("log")
    for axis in axes.reshape(-1):
        axis.set_xscale("symlog", linthresh=10)
        axis.set_xlabel("optimization step")
        axis.grid(alpha=0.22)
        axis.legend(fontsize=7, ncol=2)
    axes[1, 0].set_ylim(0, 1.01)
    axes[1, 1].set_ylim(0, 1.01)
    fig.tight_layout()
    fig.savefig(output_dir / "fixed_data_sweep.png", dpi=180)
    plt.close(fig)


def plot_curricula(
    output_dir: Path,
    rows: Sequence[dict[str, object]],
    cfg: RuntimeConfig,
) -> None:
    full_count = max(cfg.fixed_train_counts)
    names = [f"fixed_{full_count}"] + [
        condition.name for condition in cfg.conditions
        if condition.kind == "curriculum"
    ]
    colors = ("#222222", "#2a6fbb", "#1f9d76", "#d14b4b")
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    for color, name in zip(colors, names):
        group = rows_for_condition(rows, name)
        for axis, metric in (
            (axes[0, 0], "objective_train_raw_bce"),
            (axes[0, 1], "probe_raw_bce"),
            (axes[1, 0], "probe_exact_accuracy"),
            (axes[1, 1], "probe_seed_pairwise_exact_agreement"),
        ):
            steps, values = mean_curve(group, metric)
            axis.plot(steps, values, color=color, linewidth=2.0, label=name)
    for axis in axes.reshape(-1):
        axis.axvline(
            cfg.curriculum_switch_step, color="#888", linestyle=":", linewidth=1
        )
        axis.set_xscale("symlog", linthresh=10)
        axis.set_xlabel("optimization step")
        axis.grid(alpha=0.22)
        axis.legend(fontsize=8)
    axes[0, 0].set_title("Active training-objective BCE")
    axes[0, 1].set_title("Probe BCE")
    axes[1, 0].set_title("Probe exact accuracy")
    axes[1, 1].set_title("Probe pairwise seed agreement")
    axes[0, 0].set_yscale("log")
    axes[0, 1].set_yscale("log")
    axes[1, 0].set_ylim(0, 1.01)
    axes[1, 1].set_ylim(0, 1.01)
    fig.tight_layout()
    fig.savefig(output_dir / "curriculum_comparison.png", dpi=180)
    plt.close(fig)


def first_step_reaching(
    rows: Sequence[dict[str, object]], metric: str, threshold: float
) -> int | None:
    by_step = {}
    for row in rows:
        by_step.setdefault(int(row["step"]), []).append(float(row[metric]))
    for step in sorted(by_step):
        if np.mean(by_step[step]) >= threshold:
            return step
    return None


def build_summary(
    rows: Sequence[dict[str, object]],
    cfg: RuntimeConfig,
    current_step: int,
    elapsed_seconds: float,
) -> dict[str, object]:
    conditions = {}
    for condition in cfg.conditions:
        group = rows_for_condition(rows, condition.name)
        final_rows = [row for row in group if int(row["step"]) == current_step]
        conditions[condition.name] = {
            "kind": condition.kind,
            "pre_count": condition.pre_count,
            "post_count": condition.post_count,
            "pre_labels": condition.pre_labels,
            "first_objective_train_fit_step": first_step_reaching(
                group, "objective_train_exact_accuracy", 0.999
            ),
            "first_probe_99_step": first_step_reaching(
                group, "probe_exact_accuracy", 0.99
            ),
            "final_probe_exact_accuracy": (
                float(np.mean([
                    float(row["probe_exact_accuracy"]) for row in final_rows
                ])) if final_rows else None
            ),
            "final_probe_raw_bce": (
                float(np.mean([
                    float(row["probe_raw_bce"]) for row in final_rows
                ])) if final_rows else None
            ),
        }
    return {
        "experiment": "endpoint-only Mod 3 small-data grokking",
        "input_bits": cfg.input_bits,
        "output_encoding": "two binary bits for remainder 0/1/2",
        "constant_predictor_bce": (
            -(1 / 3) * math.log(1 / 3) - (2 / 3) * math.log(2 / 3)
        ),
        "current_step": current_step,
        "target_max_steps": cfg.max_steps,
        "elapsed_seconds": elapsed_seconds,
        "model_count": len(cfg.conditions) * len(cfg.model_seeds),
        "conditions": conditions,
    }


def persist_analysis(
    output_dir: Path,
    rows: Sequence[dict[str, object]],
    cfg: RuntimeConfig,
    current_step: int,
    elapsed_seconds: float,
) -> None:
    write_csv(output_dir / "trajectory.csv", rows)
    write_json(
        output_dir / "summary.json",
        build_summary(rows, cfg, current_step, elapsed_seconds),
    )
    plot_fixed_sweep(output_dir, rows, cfg)
    plot_curricula(output_dir, rows, cfg)


def config_signature(cfg: RuntimeConfig) -> dict[str, object]:
    return {
        "input_bits": cfg.input_bits,
        "fixed_train_counts": cfg.fixed_train_counts,
        "probe_count": cfg.probe_count,
        "data_seed": cfg.data_seed,
        "random_label_seed": cfg.random_label_seed,
        "conditions": [asdict(item) for item in cfg.conditions],
        "model_seeds": cfg.model_seeds,
        "hidden_size": cfg.hidden_size,
        "hidden_layer_count": cfg.hidden_layer_count,
        "activation": cfg.activation,
        "learning_rate": cfg.learning_rate,
        "warmup_steps": cfg.warmup_steps,
        "weight_decay": cfg.weight_decay,
        "batch_size": cfg.batch_size,
        "train_order_seed": cfg.train_order_seed,
        "stable_bce": cfg.numerically_stable_signed_bce,
    }


def save_checkpoint(
    path: Path,
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    generator: torch.Generator,
    rows: Sequence[dict[str, object]],
    step: int,
    cfg: RuntimeConfig,
) -> None:
    temporary = path.with_suffix(".tmp")
    torch.save({
        "step": step,
        "model": model.state_dict(),
        "optimizer": optimizer.state_dict(),
        "generator_state": generator.get_state(),
        "all_rows": list(rows),
        "config_signature": config_signature(cfg),
    }, temporary)
    temporary.replace(path)


def load_checkpoint(
    path: Path,
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    generator: torch.Generator,
    cfg: RuntimeConfig,
    device: torch.device,
) -> tuple[int, list[dict[str, object]]]:
    try:
        payload = torch.load(path, map_location=device, weights_only=False)
    except TypeError:
        payload = torch.load(path, map_location=device)
    if payload["config_signature"] != config_signature(cfg):
        raise ValueError("checkpoint 配置与当前 Config 不一致。")
    model.load_state_dict(payload["model"])
    optimizer.load_state_dict(payload["optimizer"])
    generator.set_state(payload["generator_state"])
    return int(payload["step"]), list(payload["all_rows"])


def package_results(output_dir: Path) -> Path:
    archive = output_dir.parent / f"{output_dir.name}_package.zip"
    if archive.exists():
        archive.unlink()
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as handle:
        for path in sorted(output_dir.iterdir()):
            if path.name in {"latest_checkpoint.pt", "latest_checkpoint.tmp"}:
                continue
            if path.is_file():
                handle.write(path, arcname=path.name)
    return archive


def main() -> None:
    cfg = build_runtime_config()
    validate_config(cfg)
    set_global_seed(cfg.data_seed)
    torch.set_float32_matmul_precision("high")
    if torch.cuda.is_available():
        torch.backends.cuda.matmul.allow_tf32 = True

    output_dir = cfg.result_dir
    checkpoint_path = output_dir / "latest_checkpoint.pt"
    if output_dir.exists() and cfg.overwrite_existing and not cfg.resume:
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    dataset = make_dataset(cfg)
    device = torch.device(cfg.device)
    train_x = torch.from_numpy(dataset["train_x"]).to(device)
    train_y = torch.from_numpy(dataset["train_y"]).to(device)
    train_random_y = torch.from_numpy(dataset["train_random_y"]).to(device)
    probe_x = torch.from_numpy(dataset["probe_x"]).to(device)
    probe_y = torch.from_numpy(dataset["probe_y"]).to(device)
    np.savez_compressed(
        output_dir / "dataset_split.npz",
        train_ids=dataset["train_ids"],
        probe_ids=dataset["probe_ids"],
        random_targets=dataset["train_random_y"],
    )
    write_json(output_dir / "config.json", {
        **asdict(cfg),
        "conditions": [asdict(item) for item in cfg.conditions],
        "result_dir": str(cfg.result_dir),
    })

    expanded_seeds, indices_by_condition = make_model_layout(cfg)
    model = BatchedIndependentMLP(
        input_size=cfg.input_bits,
        output_size=2,
        hidden_size=cfg.hidden_size,
        hidden_layer_count=cfg.hidden_layer_count,
        model_seeds=expanded_seeds,
        activation=cfg.activation,
        layernorm_eps=cfg.layernorm_eps,
    ).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=cfg.learning_rate, weight_decay=cfg.weight_decay
    )
    generator = torch.Generator(device=device)
    generator.manual_seed(cfg.train_order_seed)

    start_step = 0
    all_rows: list[dict[str, object]] = []
    if cfg.resume and checkpoint_path.exists():
        start_step, all_rows = load_checkpoint(
            checkpoint_path, model, optimizer, generator, cfg, device
        )
        print(f"从 checkpoint 续训：step={start_step:,}")
    elif (
        (output_dir / "trajectory.jsonl").exists()
        and not cfg.overwrite_existing
        and not cfg.smoke_test
    ):
        raise FileExistsError(
            f"结果目录已存在但没有 checkpoint：{output_dir}\n"
            "确认不需要旧结果后，将 OVERWRITE_EXISTING=True。"
        )

    parameter_count = sum(
        parameter.numel() for parameter in model.parameters()
    ) // len(expanded_seeds)
    print("=== Endpoint-only Mod 3 small-data grokking ===")
    print(f"设备：{device}")
    if device.type == "cuda":
        print(f"GPU：{torch.cuda.get_device_name(device)}")
    print(
        f"任务：{cfg.input_bits}-bit integer -> remainder mod 3 (2 bits) | "
        f"probe={cfg.probe_count:,}"
    )
    print(
        f"MLP：{cfg.input_bits} -> {cfg.hidden_size} x "
        f"{cfg.hidden_layer_count} -> 2 | 参数={parameter_count:,}"
    )
    print(
        f"固定 n：{list(cfg.fixed_train_counts)} | curricula="
        f"{[item.name for item in cfg.conditions if item.kind == 'curriculum']}"
    )
    print(
        f"switch_step={cfg.curriculum_switch_step:,} | "
        f"reset_adam={cfg.reset_adam_state_on_switch} | "
        f"并行模型={len(expanded_seeds)} | max_steps={cfg.max_steps:,}"
    )
    print(f"结果目录：{output_dir}")

    eval_steps = make_eval_steps(cfg)
    evaluated_steps = {int(row["step"]) for row in all_rows}
    trajectory_path = output_dir / "trajectory.jsonl"
    started = time.time()
    if start_step == 0 and 0 not in evaluated_steps:
        rows = evaluate_all_conditions(
            model, cfg, indices_by_condition,
            train_x, train_y, train_random_y,
            probe_x, probe_y, 0, 0.0,
        )
        all_rows.extend(rows)
        append_jsonl(trajectory_path, rows)
        evaluated_steps.add(0)

    seed_count = len(cfg.model_seeds)
    curriculum_model_indices = [
        index
        for condition in cfg.conditions if condition.kind == "curriculum"
        for index in indices_by_condition[condition.name]
    ]
    model.train()
    latest_losses = None

    for step in range(start_step + 1, cfg.max_steps + 1):
        if (
            cfg.reset_adam_state_on_switch
            and step == cfg.curriculum_switch_step + 1
        ):
            reset_optimizer_slices(optimizer, curriculum_model_indices)
            print(
                f"[课程切换] step={step:,} | 已清空课程模型 Adam moments，"
                "保留网络权重。"
            )

        lr = make_lr(step, cfg)
        for parameter_group in optimizer.param_groups:
            parameter_group["lr"] = lr

        batch_x, batch_y, batch_mask = make_training_batch(
            cfg,
            step,
            seed_count,
            generator,
            train_x,
            train_y,
            train_random_y,
        )
        logits = model(batch_x)
        per_sample_loss = elementwise_raw_bce(
            logits, batch_y, cfg.numerically_stable_signed_bce
        ).mean(dim=2)
        mask = batch_mask.float()
        loss_per_model = (
            (per_sample_loss * mask).sum(dim=1)
            / mask.sum(dim=1).clamp_min(1.0)
        )
        optimizer.zero_grad(set_to_none=True)
        loss_per_model.sum().backward()
        optimizer.step()
        latest_losses = loss_per_model.detach().view(
            len(cfg.conditions), seed_count
        ).mean(dim=1)

        if step in eval_steps and step not in evaluated_steps:
            rows = evaluate_all_conditions(
                model, cfg, indices_by_condition,
                train_x, train_y, train_random_y,
                probe_x, probe_y, step, time.time() - started,
            )
            all_rows.extend(rows)
            append_jsonl(trajectory_path, rows)
            evaluated_steps.add(step)

        if step % cfg.log_interval_steps == 0:
            elapsed = time.time() - started
            compact = " | ".join(
                f"{condition.name}:{latest_losses[index].item():.2e}"
                for index, condition in enumerate(cfg.conditions)
            )
            print(
                f"step={step:>7,}/{cfg.max_steps:,} | "
                f"{(step - start_step) / max(elapsed, 1e-9):.1f} step/s | "
                f"{compact}"
            )

        if (
            step % cfg.checkpoint_interval_steps == 0
            or step == cfg.max_steps
        ):
            elapsed = time.time() - started
            persist_analysis(output_dir, all_rows, cfg, step, elapsed)
            save_checkpoint(
                checkpoint_path, model, optimizer, generator,
                all_rows, step, cfg,
            )
            print(f"checkpoint：{checkpoint_path}")

    elapsed = time.time() - started
    persist_analysis(output_dir, all_rows, cfg, cfg.max_steps, elapsed)
    print("\n=== 实验完成 ===")
    print(f"本次运行耗时：{elapsed / 60:.2f} 分钟")
    print(f"汇总：{output_dir / 'summary.json'}")
    if cfg.package_results:
        print(f"下载压缩包：{package_results(output_dir)}")


if __name__ == "__main__":
    main()
